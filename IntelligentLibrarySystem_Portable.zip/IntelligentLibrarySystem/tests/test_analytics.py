from models import db, Book, Category, Review, BorrowRecord

def test_student_review_submission_and_average_rating(client, seed_users):
    """Verify that a student can review a book and that the average rating is computed."""
    client.post('/auth/login', data={'email': 'student@test.edu', 'password': 'StudentPass123'})

    cat = Category(name="Machine Learning", description="ML notes")
    db.session.add(cat)
    db.session.commit()

    book = Book(
        title="Deep Learning Math",
        author="Ian Goodfellow",
        isbn="978-7777777777",
        category_id=cat.id,
        description="Linear algebra and probability for deep learning",
        total_copies=2,
        available_copies=2
    )
    db.session.add(book)
    db.session.commit()

    # Submit 5-star review
    response = client.post(f'/student/submit-review/{book.id}', data={
        'rating': '5',
        'review_text': 'Exceptional mathematical rigor and clear intuitions!'
    }, follow_redirects=True)

    assert response.status_code == 200
    assert b'published' in response.data or b'updated' in response.data

    book = db.session.get(Book, book.id)
    assert book.average_rating == 5.0
    assert book.total_reviews_count == 1

    # Edit review to 4 stars
    client.post(f'/student/submit-review/{book.id}', data={
        'rating': '4',
        'review_text': 'Revised opinion: chapters on calculus are slightly terse.'
    }, follow_redirects=True)

    book = db.session.get(Book, book.id)
    assert book.average_rating == 4.0
    assert book.total_reviews_count == 1  # Not duplicated!

def test_analytics_dashboard_charts_api(client, seed_users):
    """Verify that /api/analytics/dashboard-charts returns structured Chart.js payload."""
    client.post('/auth/login', data={'email': 'admin@test.edu', 'password': 'AdminPass123'})

    response = client.get('/api/analytics/dashboard-charts')
    assert response.status_code == 200

    data = response.get_json()
    assert 'most_borrowed' in data
    assert 'category_distribution' in data
    assert 'status_distribution' in data
    assert 'labels' in data['most_borrowed']
    assert 'data' in data['most_borrowed']
    assert len(data['status_distribution']['labels']) == 4
