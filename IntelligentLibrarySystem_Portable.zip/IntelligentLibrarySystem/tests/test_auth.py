from models import User

def test_login_page_renders(client):
    """Verify login page is accessible and contains sign in elements."""
    response = client.get('/auth/login')
    assert response.status_code == 200
    assert b'Library Portal Sign In' in response.data

def test_student_registration_success(client):
    """Verify that a new student can register successfully."""
    response = client.post('/auth/register', data={
        'student_id': 'NEWREG001',
        'full_name': 'New Student',
        'email': 'newstudent@test.edu',
        'department': 'Computer Science & Engineering',
        'phone': '9876543210',
        'password': 'StrongPassword123',
        'confirm_password': 'StrongPassword123'
    }, follow_redirects=True)

    assert response.status_code == 200
    assert b'Your student account was created successfully' in response.data

    user = User.query.filter_by(email='newstudent@test.edu').first()
    assert user is not None
    assert user.student_id == 'NEWREG001'
    assert user.is_student is True
    assert user.check_password('StrongPassword123') is True

def test_student_registration_duplicate_email_fails(client, seed_users):
    """Verify duplicate email registration is rejected."""
    response = client.post('/auth/register', data={
        'student_id': 'UNIQUE001',
        'full_name': 'Duplicate Attempt',
        'email': 'student@test.edu', # Already exists in seed_users
        'department': 'AI & Data Science',
        'password': 'StrongPassword123',
        'confirm_password': 'StrongPassword123'
    }, follow_redirects=True)

    assert b'An account with this email address is already registered' in response.data

def test_admin_login_success(client, seed_users):
    """Verify admin login redirects to admin dashboard."""
    response = client.post('/auth/login', data={
        'email': 'admin@test.edu',
        'password': 'AdminPass123'
    }, follow_redirects=True)

    assert response.status_code == 200
    assert b'Admin Dashboard' in response.data

def test_student_login_success(client, seed_users):
    """Verify student login redirects to student dashboard."""
    response = client.post('/auth/login', data={
        'email': 'student@test.edu',
        'password': 'StudentPass123'
    }, follow_redirects=True)

    assert response.status_code == 200
    assert b'Welcome back, Test Student' in response.data

def test_login_invalid_password(client, seed_users):
    """Verify failed login with incorrect password."""
    response = client.post('/auth/login', data={
        'email': 'student@test.edu',
        'password': 'WrongPassword999'
    }, follow_redirects=True)

    assert b'Invalid email address or password' in response.data

def test_role_isolation_student_denied_admin_dashboard(client, seed_users):
    """Verify students cannot access admin-only routes (HTTP 403 / redirect)."""
    # 1. Login as student
    client.post('/auth/login', data={
        'email': 'student@test.edu',
        'password': 'StudentPass123'
    })

    # 2. Try to access admin dashboard
    response = client.get('/admin/dashboard')
    assert response.status_code == 403
    assert b'Access Denied' in response.data

def test_logout(client, seed_users):
    """Verify logout terminates session."""
    client.post('/auth/login', data={
        'email': 'student@test.edu',
        'password': 'StudentPass123'
    })
    response = client.get('/auth/logout', follow_redirects=True)
    assert response.status_code == 200
    assert b'You have been signed out successfully' in response.data
