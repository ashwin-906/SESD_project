from models import db, Book, Category, BorrowRecord, UserPreference, Review, User
from services.recommendation_service import RecommendationEngine

def setup_recommendation_corpus(app):
    """Populates categories and books across distinct domains for similarity testing."""
    cat_ai = Category(name="Artificial Intelligence", description="Machine learning and neural networks")
    cat_web = Category(name="Web Development", description="Frontend, backend, HTML, and JavaScript")
    cat_sec = Category(name="Cyber Security", description="Cryptography and network penetration testing")
    db.session.add_all([cat_ai, cat_web, cat_sec])
    db.session.commit()

    b1 = Book(title="Deep Learning with Neural Networks", author="Ian Goodfellow", isbn="978-0000000001", category_id=cat_ai.id, description="Convolutional and recurrent deep neural networks, backpropagation, and machine learning models.", total_copies=3, available_copies=3)
    b2 = Book(title="Machine Learning Basics", author="Christopher Bishop", isbn="978-0000000002", category_id=cat_ai.id, description="Supervised learning, classification algorithms, neural networks, and pattern recognition.", total_copies=3, available_copies=3)
    b3 = Book(title="Modern Web Applications with React", author="David Choi", isbn="978-0000000003", category_id=cat_web.id, description="React components, state management, JavaScript, CSS, and full-stack REST API development.", total_copies=3, available_copies=3)
    b4 = Book(title="Practical Cryptography and Ciphers", author="William Stallings", isbn="978-0000000004", category_id=cat_sec.id, description="Symmetric encryption, RSA public keys, network ciphers, and ethical hacking protocols.", total_copies=3, available_copies=3)
    b5 = Book(title="Advanced AI and Reinforcement Learning", author="Richard Sutton", isbn="978-0000000005", category_id=cat_ai.id, description="Markov decision processes, deep Q-learning, policy gradients, and intelligent autonomous agents.", total_copies=3, available_copies=3)

    db.session.add_all([b1, b2, b3, b4, b5])
    db.session.commit()
    return {"ai": [b1, b2, b5], "web": [b3], "sec": [b4], "categories": [cat_ai, cat_web, cat_sec]}

def test_similar_books_pairwise_similarity(app):
    """Verify that similar books returns titles sharing vocabulary and domain."""
    books_data = setup_recommendation_corpus(app)
    engine = RecommendationEngine()

    deep_learning_book = books_data["ai"][0] # Deep Learning
    similar = engine.get_similar_books(deep_learning_book.id, top_n=2)

    assert len(similar) > 0
    top_sim_titles = [s['book'].title for s in similar]
    # "Machine Learning Basics" or "Advanced AI" should rank above "Modern Web Applications"
    assert "Machine Learning Basics" in top_sim_titles or "Advanced AI and Reinforcement Learning" in top_sim_titles
    assert "Modern Web Applications with React" not in top_sim_titles

def test_personalized_recommendations_from_borrow_history(app, seed_users):
    """Verify that a student who borrowed an AI book receives AI recommendations, excluding the borrowed book."""
    books_data = setup_recommendation_corpus(app)
    student = seed_users["student"]
    engine = RecommendationEngine()

    borrowed_book = books_data["ai"][0] # Deep Learning
    record = BorrowRecord(user_id=student.id, book_id=borrowed_book.id, status=BorrowRecord.STATUS_ISSUED)
    db.session.add(record)
    db.session.commit()

    recs = engine.get_personalized_recommendations(user_id=student.id, top_n=3)
    rec_titles = [r['book'].title for r in recs]

    # Exclude already borrowed book
    assert borrowed_book.title not in rec_titles
    # Highly similar AI books should be recommended
    assert any("Learning" in title or "AI" in title for title in rec_titles)
    # Check that explanation is provided
    assert any("borrowed" in r['reason'].lower() or "interest" in r['reason'].lower() or "ai" in r['reason'].lower() for r in recs)

def test_cold_start_category_preferences(app, seed_users):
    """Verify that a new student with no borrow history gets recommendations matching selected category preferences."""
    books_data = setup_recommendation_corpus(app)
    student = seed_users["student"]
    engine = RecommendationEngine()

    web_category = books_data["categories"][1] # Web Development
    pref = UserPreference(user_id=student.id, category_id=web_category.id)
    db.session.add(pref)
    db.session.commit()

    recs = engine.get_personalized_recommendations(user_id=student.id, top_n=2)
    assert len(recs) > 0
    top_rec = recs[0]
    assert top_rec['book'].category_id == web_category.id
    assert "Web Development" in top_rec['reason']
