from models import db, Book, Category, BorrowRecord

def test_catalogue_renders(client, seed_users):
    """Verify public catalogue view is accessible and renders books."""
    # Seed a category and book
    cat = Category(name="Algorithms", description="Algo notes")
    db.session.add(cat)
    db.session.commit()

    book = Book(
        title="Intro to Python",
        author="Guido van Rossum",
        isbn="978-0123456789",
        category_id=cat.id,
        description="Core Python language principles and syntax.",
        total_copies=3,
        available_copies=3
    )
    db.session.add(book)
    db.session.commit()

    response = client.get('/student/catalogue')
    assert response.status_code == 200
    assert b'Intro to Python' in response.data
    assert b'Guido van Rossum' in response.data

def test_catalogue_search_and_filter(client, seed_users):
    """Verify search filter works for matching titles."""
    cat = Category(name="Systems", description="OS notes")
    db.session.add(cat)
    db.session.commit()

    b1 = Book(title="Distributed Systems", author="Tanenbaum", isbn="978-1111111111", category_id=cat.id, description="Desc", total_copies=2, available_copies=2)
    b2 = Book(title="Compiler Design", author="Aho", isbn="978-2222222222", category_id=cat.id, description="Desc", total_copies=2, available_copies=2)
    db.session.add_all([b1, b2])
    db.session.commit()

    # Search for "Compiler"
    response = client.get('/student/catalogue?q=Compiler')
    assert response.status_code == 200
    assert b'Compiler Design' in response.data
    assert b'Distributed Systems' not in response.data

def test_admin_add_book_success(client, seed_users):
    """Verify admin can add a new book record."""
    # Login as admin
    client.post('/auth/login', data={'email': 'admin@test.edu', 'password': 'AdminPass123'})

    cat = Category(name="Database Systems", description="SQL notes")
    db.session.add(cat)
    db.session.commit()

    response = client.post('/admin/books/new', data={
        'title': 'Database Internals',
        'author': 'Alex Petrov',
        'isbn': '978-1492040347',
        'publisher': "O'Reilly Media",
        'publication_year': '2019',
        'category_id': str(cat.id),
        'description': 'A comprehensive guide to storage engines, B-trees, LSM-trees, and distributed consensus algorithms.',
        'total_copies': '4',
        'available_copies': '4'
    }, follow_redirects=True)

    assert response.status_code == 200
    assert b'was successfully added to the catalogue' in response.data

    new_book = Book.query.filter_by(isbn='978-1492040347').first()
    assert new_book is not None
    assert new_book.title == 'Database Internals'
    assert new_book.total_copies == 4
    assert new_book.available_copies == 4

def test_admin_prevent_duplicate_isbn(client, seed_users):
    """Verify that adding a book with an existing ISBN is rejected."""
    client.post('/auth/login', data={'email': 'admin@test.edu', 'password': 'AdminPass123'})

    cat = Category(name="Security", description="Sec notes")
    db.session.add(cat)
    db.session.commit()

    b1 = Book(title="Original Book", author="Author 1", isbn="978-9999999999", category_id=cat.id, description="Desc", total_copies=2, available_copies=2)
    db.session.add(b1)
    db.session.commit()

    # Attempt to add another book with same ISBN
    response = client.post('/admin/books/new', data={
        'title': 'Copycat Book',
        'author': 'Author 2',
        'isbn': '978-9999999999',
        'category_id': str(cat.id),
        'description': 'Duplicate ISBN book',
        'total_copies': '1',
        'available_copies': '1'
    }, follow_redirects=True)

    assert b'A book with this ISBN is already registered' in response.data

def test_admin_delete_book_blocked_if_issued(client, seed_users):
    """Verify admin cannot delete a book if copies are currently issued to students."""
    client.post('/auth/login', data={'email': 'admin@test.edu', 'password': 'AdminPass123'})

    cat = Category(name="AI", description="AI notes")
    db.session.add(cat)
    db.session.commit()

    book = Book(title="Active Loan Book", author="Author", isbn="978-8888888888", category_id=cat.id, description="Desc", total_copies=2, available_copies=1)
    db.session.add(book)
    db.session.commit()

    student = seed_users['student']
    loan = BorrowRecord(user_id=student.id, book_id=book.id, status=BorrowRecord.STATUS_ISSUED)
    db.session.add(loan)
    db.session.commit()

    # Attempt delete
    response = client.post(f'/admin/books/{book.id}/delete', follow_redirects=True)
    assert b'Cannot delete' in response.data
    assert db.session.get(Book, book.id) is not None
