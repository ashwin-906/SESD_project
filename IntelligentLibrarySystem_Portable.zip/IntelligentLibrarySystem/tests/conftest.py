import pytest
from app import create_app
from models import db, User, Category, Book

@pytest.fixture
def app():
    """Create and configure a clean testing app instance."""
    app = create_app('testing')
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.fixture
def client(app):
    """A test client for making simulated HTTP requests."""
    return app.test_client()

@pytest.fixture
def runner(app):
    """A test CLI runner for app commands."""
    return app.test_cli_runner()

@pytest.fixture
def seed_users(app):
    """Seeds one admin and one student for testing."""
    admin = User(
        full_name="Admin Librarian",
        email="admin@test.edu",
        role=User.ROLE_ADMIN,
        department="Library Services"
    )
    admin.set_password("AdminPass123")

    student = User(
        student_id="TEST001",
        full_name="Test Student",
        email="student@test.edu",
        role=User.ROLE_STUDENT,
        department="Computer Science & Engineering"
    )
    student.set_password("StudentPass123")

    db.session.add_all([admin, student])
    db.session.commit()
    return {"admin": admin, "student": student}
