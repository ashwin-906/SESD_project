from datetime import datetime, timedelta
from models import db, Book, Category, BorrowRecord, User
from services.library_service import LibraryService

def setup_book_and_student(db_session, seed_users):
    cat = Category(name="Algorithms", description="Algo notes")
    db.session.add(cat)
    db.session.commit()

    book = Book(
        title="CLRS Algorithms",
        author="Cormen",
        isbn="978-0262033848",
        category_id=cat.id,
        description="Core algorithms text",
        total_copies=3,
        available_copies=3
    )
    db.session.add(book)
    db.session.commit()
    return book, seed_users['student']

def test_student_request_borrow_success(client, seed_users):
    """Verify that a student can request to borrow an in-stock book."""
    client.post('/auth/login', data={'email': 'student@test.edu', 'password': 'StudentPass123'})
    book, student = setup_book_and_student(db.session, seed_users)

    response = client.post(f'/student/request-borrow/{book.id}', follow_redirects=True)
    assert response.status_code == 200
    assert b'submitted' in response.data

    record = BorrowRecord.query.filter_by(user_id=student.id, book_id=book.id).first()
    assert record is not None
    assert record.status == BorrowRecord.STATUS_PENDING

def test_prevent_duplicate_active_borrow_request(client, seed_users):
    """Verify student cannot place multiple active requests for the same book."""
    client.post('/auth/login', data={'email': 'student@test.edu', 'password': 'StudentPass123'})
    book, student = setup_book_and_student(db.session, seed_users)

    # First request
    client.post(f'/student/request-borrow/{book.id}', follow_redirects=True)

    # Second duplicate request
    response = client.post(f'/student/request-borrow/{book.id}', follow_redirects=True)
    assert b'already have an active request or loan' in response.data

def test_prevent_borrow_out_of_stock_book(client, seed_users):
    """Verify student cannot request an out-of-stock book."""
    client.post('/auth/login', data={'email': 'student@test.edu', 'password': 'StudentPass123'})
    book, student = setup_book_and_student(db.session, seed_users)

    # Set available copies to 0
    book.available_copies = 0
    db.session.commit()

    response = client.post(f'/student/request-borrow/{book.id}', follow_redirects=True)
    assert b'currently out of stock' in response.data

def test_admin_approve_and_issue_workflow(client, seed_users):
    """Verify approval, issuing, and atomic inventory decrement."""
    book, student = setup_book_and_student(db.session, seed_users)

    # Create pending request
    record = BorrowRecord(user_id=student.id, book_id=book.id, status=BorrowRecord.STATUS_PENDING)
    db.session.add(record)
    db.session.commit()

    # Login as admin
    client.post('/auth/login', data={'email': 'admin@test.edu', 'password': 'AdminPass123'})

    # Approve request
    response = client.post(f'/admin/requests/{record.id}/approve', follow_redirects=True)
    assert response.status_code == 200

    record = db.session.get(BorrowRecord, record.id)
    assert record.status == BorrowRecord.STATUS_APPROVED

    # Issue book (14 days)
    initial_copies = book.available_copies
    response = client.post(f'/admin/loans/{record.id}/issue', data={'loan_days': '14'}, follow_redirects=True)
    assert response.status_code == 200

    record = db.session.get(BorrowRecord, record.id)
    assert record.status == BorrowRecord.STATUS_ISSUED
    assert record.issue_date is not None
    assert record.due_date is not None
    # Check inventory decremented
    book = db.session.get(Book, book.id)
    assert book.available_copies == initial_copies - 1

def test_admin_return_and_fine_calculation(client, seed_users):
    """Verify return restores inventory and calculates overdue fines accurately."""
    book, student = setup_book_and_student(db.session, seed_users)
    now = datetime.utcnow()

    # Create an overdue issued loan (5 days overdue)
    record = BorrowRecord(
        user_id=student.id,
        book_id=book.id,
        status=BorrowRecord.STATUS_ISSUED,
        request_date=now - timedelta(days=20),
        issue_date=now - timedelta(days=19),
        due_date=now - timedelta(days=5) # 5 days overdue
    )
    book.available_copies = 2
    db.session.add(record)
    db.session.commit()

    # Login as admin and process return
    client.post('/auth/login', data={'email': 'admin@test.edu', 'password': 'AdminPass123'})
    response = client.post(f'/admin/loans/{record.id}/return', follow_redirects=True)
    assert response.status_code == 200

    record = db.session.get(BorrowRecord, record.id)
    assert record.status == BorrowRecord.STATUS_RETURNED
    assert record.return_date is not None
    # 5 days * 5.0 = 25.0 fine
    assert record.fine_amount == 25.0

    # Check inventory restored
    book = db.session.get(Book, book.id)
    assert book.available_copies == 3

def test_student_cancel_pending_request(client, seed_users):
    """Verify student can cancel their own pending request."""
    client.post('/auth/login', data={'email': 'student@test.edu', 'password': 'StudentPass123'})
    book, student = setup_book_and_student(db.session, seed_users)

    record = BorrowRecord(user_id=student.id, book_id=book.id, status=BorrowRecord.STATUS_PENDING)
    db.session.add(record)
    db.session.commit()

    response = client.post(f'/student/my-loans/{record.id}/cancel', follow_redirects=True)
    assert response.status_code == 200
    assert db.session.get(BorrowRecord, record.id) is None
