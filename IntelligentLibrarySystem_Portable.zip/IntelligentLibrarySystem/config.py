import os
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(__file__))

# Automatically load environment variables from .env file if present in the project directory
env_path = os.path.join(basedir, '.env')
if os.path.exists(env_path):
    load_dotenv(env_path)

# Normalize SQLite database path to use forward slashes (works seamlessly across Windows, Linux, and macOS)
default_db_path = os.path.abspath(os.path.join(basedir, 'database', 'library.db')).replace('\\', '/')
default_db_uri = f"sqlite:///{default_db_path}"

class Config:
    """Base application configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'intelligent-library-secret-key-2026-portable')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload

    # Configurable library business logic settings
    DEFAULT_LOAN_DAYS = int(os.environ.get('DEFAULT_LOAN_DAYS', 14))
    DAILY_FINE_RATE = float(os.environ.get('DAILY_FINE_RATE', 5.0))  # ₹5.00 per day for overdue returns
    MAX_ACTIVE_LOANS_PER_STUDENT = int(os.environ.get('MAX_ACTIVE_LOANS_PER_STUDENT', 3))
    TOP_RECOMMENDATIONS_COUNT = int(os.environ.get('TOP_RECOMMENDATIONS_COUNT', 5))

class DevelopmentConfig(Config):
    """Development environment configuration."""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or os.environ.get('DEV_DATABASE_URL') or default_db_uri

class TestingConfig(Config):
    """Testing environment configuration with in-memory database."""
    TESTING = True
    WTF_CSRF_ENABLED = False
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    DEBUG = True

class ProductionConfig(Config):
    """Production environment configuration."""
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or default_db_uri

config_by_name = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
