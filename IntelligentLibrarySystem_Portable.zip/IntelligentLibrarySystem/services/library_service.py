from datetime import datetime, timedelta
from models import db, BorrowRecord, Book

class LibraryService:
    """
    Business service encapsulating book borrowing, issuing, returns,
    atomic inventory copy updates, and fine calculations.
    """

    @staticmethod
    def approve_request(record_id: int):
        """Transitions a PENDING borrow request to APPROVED."""
        record = db.session.get(BorrowRecord, record_id)
        if not record or record.status != BorrowRecord.STATUS_PENDING:
            return False, "Invalid or non-pending request."

        record.status = BorrowRecord.STATUS_APPROVED
        db.session.commit()
        return True, f"Request #{record.id} approved for {record.user.full_name}."

    @staticmethod
    def reject_request(record_id: int, reason: str = None):
        """Rejects a PENDING borrow request with an optional note."""
        record = db.session.get(BorrowRecord, record_id)
        if not record or record.status != BorrowRecord.STATUS_PENDING:
            return False, "Invalid or non-pending request."

        record.status = BorrowRecord.STATUS_REJECTED
        if reason:
            record.notes = f"Rejection reason: {reason}"
        db.session.commit()
        return True, f"Request #{record.id} was rejected."

    @staticmethod
    def issue_book(record_id: int, loan_days: int = 14):
        """
        Physically issues a book to a student:
        1. Verifies available copies > 0.
        2. Atomically decrements available_copies.
        3. Sets status to ISSUED with issue_date and due_date.
        """
        record = db.session.get(BorrowRecord, record_id)
        if not record or record.status not in (BorrowRecord.STATUS_PENDING, BorrowRecord.STATUS_APPROVED):
            return False, "Only pending or approved requests can be issued."

        book = record.book
        if book.available_copies < 1:
            return False, f"Cannot issue '{book.title}': No available copies in stock."

        now = datetime.utcnow()
        try:
            # Atomic inventory update
            book.available_copies -= 1
            record.status = BorrowRecord.STATUS_ISSUED
            record.issue_date = now
            record.due_date = now + timedelta(days=loan_days)
            db.session.commit()
            return True, f"Book '{book.title}' successfully issued to {record.user.full_name}. Due on {record.due_date.strftime('%d %b %Y')}."
        except Exception as e:
            db.session.rollback()
            return False, f"Failed to issue book: {str(e)}"

    @staticmethod
    def return_book(record_id: int, daily_fine_rate: float = 5.0):
        """
        Records the physical return of an issued book:
        1. Atomically increments available_copies.
        2. Sets return_date = now and status = RETURNED.
        3. Computes overdue fine if return_date > due_date.
        """
        record = db.session.get(BorrowRecord, record_id)
        if not record or record.status != BorrowRecord.STATUS_ISSUED:
            return False, "Only currently issued books can be returned."

        book = record.book
        now = datetime.utcnow()

        try:
            # Compute fine
            record.return_date = now
            record.status = BorrowRecord.STATUS_RETURNED

            if record.due_date and now > record.due_date:
                overdue_days = (now - record.due_date).days
                if overdue_days > 0:
                    record.fine_amount = round(overdue_days * daily_fine_rate, 2)
                    record.notes = (record.notes or "") + f" [Overdue by {overdue_days} days. Fine assessed: ₹{record.fine_amount}]"

            # Restore available copy
            if book.available_copies < book.total_copies:
                book.available_copies += 1

            db.session.commit()
            fine_msg = f" Overdue fine assessed: ₹{record.fine_amount:.2f}." if record.fine_amount > 0 else " No overdue fine."
            return True, f"'{book.title}' returned successfully by {record.user.full_name}.{fine_msg}"
        except Exception as e:
            db.session.rollback()
            return False, f"Failed to process return: {str(e)}"

    @staticmethod
    def cancel_student_request(record_id: int, user_id: int):
        """Allows a student to cancel their own pending borrow request."""
        record = db.session.get(BorrowRecord, record_id)
        if not record or record.user_id != user_id:
            return False, "Record not found or unauthorized."

        if record.status != BorrowRecord.STATUS_PENDING:
            return False, "Only pending requests can be cancelled."

        db.session.delete(record)
        db.session.commit()
        return True, "Borrow request has been cancelled."
