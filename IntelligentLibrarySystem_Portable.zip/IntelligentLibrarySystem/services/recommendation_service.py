"""
Intelligent Book Recommendation Engine
Uses TF-IDF Vectorization and Cosine Similarity to provide personalized,
content-based book recommendations with explainability and cold-start support.
"""

from typing import List, Dict, Any, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from models import db, Book, Category, BorrowRecord, UserPreference, Review, User

class RecommendationEngine:
    """
    Content-Based Book Recommendation Engine.
    Processes book metadata (titles, authors, categories, descriptions) into TF-IDF feature
    vectors and matches them with student preference profiles using Cosine Similarity.
    """

    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            stop_words='english',
            ngram_range=(1, 2),
            sublinear_tf=True
        )

    def _prepare_book_corpus(self, books: List[Book]) -> Tuple[List[str], Dict[int, int]]:
        """
        Builds a rich textual representation for each book.
        Category and title are repeated to grant higher term frequency weighting.
        Returns:
            corpus: List of processed text strings.
            id_to_idx: Map from book.id to matrix row index.
        """
        corpus = []
        id_to_idx = {}
        for idx, book in enumerate(books):
            id_to_idx[book.id] = idx
            cat_name = book.category.name if book.category else ""
            cat_desc = book.category.description if (book.category and book.category.description) else ""
            # Boost title and category importance by repetition
            feature_text = (
                f"{book.title} {book.title} "
                f"{book.author} "
                f"{cat_name} {cat_name} "
                f"{cat_desc} "
                f"{book.publisher or ''} "
                f"{book.description}"
            ).lower()
            corpus.append(feature_text)
        return corpus, id_to_idx

    def get_similar_books(self, target_book_id: int = None, book_id: int = None, top_n: int = 4) -> List[Dict[str, Any]]:
        """
        Computes pairwise cosine similarity between a target book and all catalogue books.
        Used for 'Similar Books' section on the book detail page.
        """
        target_id = target_book_id or book_id
        if not target_id:
            return []

        all_books = Book.query.all()
        if len(all_books) <= 1:
            return []

        target_book = db.session.get(Book, target_id)
        if not target_book:
            return []

        corpus, id_to_idx = self._prepare_book_corpus(all_books)
        tfidf_matrix = self.vectorizer.fit_transform(corpus)

        if target_id not in id_to_idx:
            return []

        target_idx = id_to_idx[target_id]
        target_vec = tfidf_matrix[target_idx]

        # Calculate cosine similarity with all books
        sim_scores = cosine_similarity(target_vec, tfidf_matrix).flatten()

        # Sort descending, excluding the target book itself
        ranked_indices = np.argsort(sim_scores)[::-1]

        results = []
        for idx in ranked_indices:
            candidate_book = all_books[idx]
            if candidate_book.id == target_book_id:
                continue

            score = float(sim_scores[idx])
            results.append({
                'book': candidate_book,
                'score': round(score, 3),
                'reason': f"Shares {int(score * 100)}% thematic similarity in {candidate_book.category.name}"
            })

            if len(results) >= top_n:
                break

        return results

    def get_personalized_recommendations(self, user_id: int, top_n: int = 5) -> List[Dict[str, Any]]:
        """
        Generates personalized book recommendations for a student:
        1. Analyzes borrow history (weight = 2.0).
        2. Analyzes 4+ star ratings (weight = 1.5).
        3. Analyzes chosen favorite categories (weight = 1.0).
        4. Excludes books already borrowed or requested.
        5. Prioritizes in-stock books.
        6. Generates human-readable explanation tags.
        """
        user = db.session.get(User, user_id)
        if not user or not user.is_student:
            return self._get_fallback_popular_recommendations(top_n=top_n)

        all_books = Book.query.all()
        if not all_books:
            return []

        # Find books already borrowed or requested by this user
        user_records = BorrowRecord.query.filter_by(user_id=user_id).all()
        interacted_book_ids = {r.book_id for r in user_records}

        # Candidate books to recommend (exclude already borrowed)
        candidate_books = [b for b in all_books if b.id not in interacted_book_ids and b.available_copies > 0]
        if not candidate_books:
            # Fallback if student borrowed all books or all candidate books out of stock
            candidate_books = [b for b in all_books if b.id not in interacted_book_ids]
            if not candidate_books:
                candidate_books = all_books

        # Collect user preference signals
        # 1. Borrow history
        borrowed_book_ids = {r.book_id for r in user_records if r.status in (BorrowRecord.STATUS_ISSUED, BorrowRecord.STATUS_RETURNED)}
        
        # 2. High ratings (>= 4 stars)
        high_rated_reviews = Review.query.filter(Review.user_id == user_id, Review.rating >= 4).all()
        liked_book_ids = {rev.book_id for rev in high_rated_reviews}

        # 3. Favorite category IDs
        pref_category_ids = {p.category_id for p in user.preferences.all()}

        # -------------------------------------------------------------
        # COLD-START CASE 1: Student has no borrowing history or ratings
        # -------------------------------------------------------------
        if not borrowed_book_ids and not liked_book_ids:
            if pref_category_ids:
                return self._get_category_based_recommendations(
                    user_id=user_id,
                    pref_category_ids=pref_category_ids,
                    candidate_books=candidate_books,
                    top_n=top_n
                )
            else:
                return self._get_fallback_popular_recommendations(
                    candidate_books=candidate_books,
                    top_n=top_n
                )

        # -------------------------------------------------------------
        # WARM PROFILE: Compute Student Vector & Cosine Similarity
        # -------------------------------------------------------------
        corpus, id_to_idx = self._prepare_book_corpus(all_books)
        tfidf_matrix = self.vectorizer.fit_transform(corpus)

        # Build composite student interest profile vector
        user_vector = np.zeros(tfidf_matrix.shape[1])

        # Positive weights
        for b_id in borrowed_book_ids:
            if b_id in id_to_idx:
                user_vector += 2.0 * tfidf_matrix[id_to_idx[b_id]].toarray().flatten()

        for b_id in liked_book_ids:
            if b_id in id_to_idx:
                user_vector += 1.5 * tfidf_matrix[id_to_idx[b_id]].toarray().flatten()

        # Add favorite categories text signal
        if pref_category_ids:
            pref_cats = Category.query.filter(Category.id.in_(pref_category_ids)).all()
            pref_text = " ".join([f"{c.name} {c.description or ''}" for c in pref_cats]).lower()
            cat_vector = self.vectorizer.transform([pref_text]).toarray().flatten()
            user_vector += 1.0 * cat_vector

        # Normalize user profile vector
        norm = np.linalg.norm(user_vector)
        if norm > 0:
            user_vector = user_vector / norm
        else:
            return self._get_fallback_popular_recommendations(candidate_books=candidate_books, top_n=top_n)

        # Compute cosine similarity for all candidate books
        candidate_indices = [id_to_idx[b.id] for b in candidate_books]
        candidate_matrix = tfidf_matrix[candidate_indices]

        scores = cosine_similarity(user_vector.reshape(1, -1), candidate_matrix).flatten()

        # Rank candidates
        ranked_order = np.argsort(scores)[::-1]

        recommendations = []
        for idx in ranked_order:
            book = candidate_books[idx]
            sim_score = float(scores[idx])

            # Determine human-friendly explanation
            reason = self._generate_explanation(book, borrowed_book_ids, liked_book_ids, pref_category_ids)

            recommendations.append({
                'book': book,
                'score': round(sim_score, 3),
                'reason': reason
            })

            if len(recommendations) >= top_n:
                break

        return recommendations

    def _generate_explanation(self, book: Book, borrowed_ids: set, liked_ids: set, pref_cat_ids: set) -> str:
        """Generates an intuitive explanation for viva demonstration."""
        # 1. Check if matches student's favorite category
        if book.category_id in pref_cat_ids:
            return f"Matches your chosen interest in {book.category.name}"

        # 2. Check if related to a borrowed book in the same category
        borrowed_books_same_cat = Book.query.filter(Book.id.in_(borrowed_ids), Book.category_id == book.category_id).first()
        if borrowed_books_same_cat:
            return f"Recommended because you borrowed '{borrowed_books_same_cat.title}'"

        # 3. Check if related to a high-rated book
        liked_book = Book.query.filter(Book.id.in_(liked_ids)).first()
        if liked_book:
            return f"Recommended based on your high rating for '{liked_book.title}'"

        # 4. Default explanation
        if book.average_rating >= 4.0:
            return f"Top-rated academic book ({book.average_rating}★) in {book.category.name}"
        return f"Popular choice among students studying {book.category.name}"

    def _get_category_based_recommendations(self, user_id: int, pref_category_ids: set, candidate_books: List[Book], top_n: int) -> List[Dict[str, Any]]:
        """Cold-start strategy for new students who have selected favorite genres."""
        matching_books = [b for b in candidate_books if b.category_id in pref_category_ids]
        # Sort by available copies and rating
        matching_books.sort(key=lambda b: (b.average_rating, b.available_copies), reverse=True)

        recommendations = []
        for book in matching_books[:top_n]:
            recommendations.append({
                'book': book,
                'score': 0.85,
                'reason': f"Suggested based on your interest in {book.category.name}"
            })

        # Fill remaining slots with popular books if fewer than top_n
        if len(recommendations) < top_n:
            remaining_slots = top_n - len(recommendations)
            existing_ids = {r['book'].id for r in recommendations}
            other_books = [b for b in candidate_books if b.id not in existing_ids]
            other_books.sort(key=lambda b: b.average_rating, reverse=True)
            for book in other_books[:remaining_slots]:
                recommendations.append({
                    'book': book,
                    'score': 0.70,
                    'reason': f"Highly recommended library classic ({book.average_rating}★)"
                })

        return recommendations

    def _get_fallback_popular_recommendations(self, candidate_books: List[Book] = None, top_n: int = 5) -> List[Dict[str, Any]]:
        """Cold-start fallback for new users with zero history and zero preferences."""
        if candidate_books is None:
            candidate_books = Book.query.filter(Book.available_copies > 0).all()

        # Sort by average rating and number of reviews
        sorted_books = sorted(candidate_books, key=lambda b: (b.average_rating, b.total_reviews_count), reverse=True)

        recommendations = []
        for book in sorted_books[:top_n]:
            recommendations.append({
                'book': book,
                'score': 0.75,
                'reason': f"Trending title with {book.average_rating}★ student rating"
            })
        return recommendations

# Global instance for clean import across routes and blueprints
recommendation_engine = RecommendationEngine()
