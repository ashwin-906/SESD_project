from functools import wraps
from flask import abort, flash, redirect, url_for, request
from flask_login import current_user

def admin_required(f):
    """
    Decorator to protect routes accessible only by Administrators / Librarians.
    Redirects unauthenticated users to login and denies students with HTTP 403.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in with administrator privileges to access this area.', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        if not current_user.is_admin:
            flash('Access denied: Administrator privileges required.', 'danger')
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def student_required(f):
    """
    Decorator to protect student-specific pages (e.g. My Loans, Ratings, Preferences).
    Redirects unauthenticated users to login.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in to your student account to access this page.', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        if not current_user.is_student:
            flash('This section is tailored for student accounts.', 'info')
            return redirect(url_for('admin.dashboard'))
        return f(*args, **kwargs)
    return decorated_function
