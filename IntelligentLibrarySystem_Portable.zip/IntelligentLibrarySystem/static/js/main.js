/**
 * Intelligent Library Management System - Client Scripts
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Auto-dismiss flash alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                bsAlert.close();
            }
        }, 5000);
    });

    // 2. Initialize Interactive Star Rating if present
    initStarRating();

    // 3. Confirm Delete Handlers
    initConfirmDialogs();
});

/**
 * Handles interactive 5-star rating selection on book detail pages.
 */
function initStarRating() {
    const starContainer = document.querySelector('.star-rating-interactive');
    const ratingInput = document.getElementById('rating-value-input');
    if (!starContainer || !ratingInput) return;

    const stars = starContainer.querySelectorAll('i');

    function highlightStars(val) {
        stars.forEach(star => {
            const starVal = parseInt(star.getAttribute('data-value'));
            if (starVal <= val) {
                star.classList.remove('fa-regular');
                star.classList.add('fa-solid', 'active', 'hovered');
            } else {
                star.classList.remove('fa-solid', 'active', 'hovered');
                star.classList.add('fa-regular');
            }
        });
    }

    function resetStars() {
        const currentVal = parseInt(ratingInput.value) || 0;
        stars.forEach(star => {
            const starVal = parseInt(star.getAttribute('data-value'));
            star.classList.remove('hovered');
            if (starVal <= currentVal) {
                star.classList.remove('fa-regular');
                star.classList.add('fa-solid', 'active');
            } else {
                star.classList.remove('fa-solid', 'active');
                star.classList.add('fa-regular');
            }
        });
    }

    stars.forEach(star => {
        star.addEventListener('mouseenter', function () {
            const val = parseInt(this.getAttribute('data-value'));
            highlightStars(val);
        });

        star.addEventListener('click', function () {
            const val = parseInt(this.getAttribute('data-value'));
            ratingInput.value = val;
            resetStars();
        });
    });

    starContainer.addEventListener('mouseleave', resetStars);
    resetStars();
}

/**
 * Attaches confirmation prompts to sensitive action buttons (e.g. book deletion).
 */
function initConfirmDialogs() {
    const confirmButtons = document.querySelectorAll('[data-confirm]');
    confirmButtons.forEach(btn => {
        btn.addEventListener('click', function (e) {
            const message = this.getAttribute('data-confirm') || 'Are you sure you want to proceed with this action?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });
}

/**
 * Viva Demo Helpers: Quick autofill buttons for login testing
 */
function autofillAdmin() {
    const emailField = document.getElementById('email');
    const pwdField = document.getElementById('password');
    if (emailField && pwdField) {
        emailField.value = 'admin@library.edu';
        pwdField.value = 'Admin@123';
    }
}

function autofillStudent() {
    const emailField = document.getElementById('email');
    const pwdField = document.getElementById('password');
    if (emailField && pwdField) {
        emailField.value = 'rahul@student.edu';
        pwdField.value = 'Student@123';
    }
}
