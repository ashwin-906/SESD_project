/**
 * Intelligent Library Management System - Chart.js Visualizations
 * Loads dynamic metrics from /api/analytics/dashboard-charts
 */

document.addEventListener('DOMContentLoaded', function () {
    const mostBorrowedCtx = document.getElementById('mostBorrowedChart');
    const categoryCtx = document.getElementById('categoryChart');
    const statusCtx = document.getElementById('statusChart');

    if (!mostBorrowedCtx && !categoryCtx && !statusCtx) {
        return;
    }

    fetch('/api/analytics/dashboard-charts')
        .then(response => {
            if (!response.ok) throw new Error('Failed to load chart analytics');
            return response.json();
        })
        .then(data => {
            // 1. Most Borrowed Books Bar Chart
            if (mostBorrowedCtx && data.most_borrowed) {
                new Chart(mostBorrowedCtx, {
                    type: 'bar',
                    data: {
                        labels: data.most_borrowed.labels,
                        datasets: [{
                            label: 'Times Borrowed',
                            data: data.most_borrowed.data,
                            backgroundColor: '#2563eb',
                            borderColor: '#1d4ed8',
                            borderWidth: 1,
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { stepSize: 1 }
                            },
                            x: {
                                ticks: {
                                    font: { size: 11 }
                                }
                            }
                        }
                    }
                });
            }

            // 2. Category Distribution Doughnut Chart
            if (categoryCtx && data.category_distribution) {
                new Chart(categoryCtx, {
                    type: 'doughnut',
                    data: {
                        labels: data.category_distribution.labels,
                        datasets: [{
                            data: data.category_distribution.data,
                            backgroundColor: [
                                '#1e3a8a',
                                '#0284c7',
                                '#0d9488',
                                '#f59e0b',
                                '#dc2626',
                                '#7c3aed',
                                '#db2777'
                            ],
                            borderWidth: 2,
                            borderColor: '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    boxWidth: 12,
                                    font: { size: 11 }
                                }
                            }
                        },
                        cutout: '65%'
                    }
                });
            }

            // 3. Loan Status Doughnut Chart
            if (statusCtx && data.status_distribution) {
                new Chart(statusCtx, {
                    type: 'doughnut',
                    data: {
                        labels: data.status_distribution.labels,
                        datasets: [{
                            data: data.status_distribution.data,
                            backgroundColor: [
                                '#3b82f6', // Active - Blue
                                '#ef4444', // Overdue - Red
                                '#f59e0b', // Pending - Amber
                                '#10b981'  // Returned - Green
                            ],
                            borderWidth: 2,
                            borderColor: '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    boxWidth: 12,
                                    font: { size: 11 }
                                }
                            }
                        },
                        cutout: '60%'
                    }
                });
            }
        })
        .catch(err => {
            console.error('Error rendering dashboard charts:', err);
        });
});
