"""
Database seeding script for Intelligent Library Management System.
Populates:
- 1 Administrator account
- 3 Realistic Student accounts
- 6 Academic Categories
- 24 Curated Academic Computer Science books with rich descriptions
- Sample student favourite category preferences
- Sample borrowing records across various lifecycle states (Pending, Issued, Overdue, Returned)
- Sample ratings and reviews for recommendation engine training

Usage:
  python seed.py          # Seeds fresh database, or preserves existing data if already populated
  python seed.py --reset  # Force wipes existing database and re-seeds from scratch
"""

import sys
import os
from datetime import datetime, timedelta
from app import create_app
from models import db, User, Category, Book, BorrowRecord, UserPreference, Review

def seed_database(force_reset: bool = False):
    app = create_app('development')
    with app.app_context():
        # Ensure database directory exists
        db_dir = os.path.join(app.root_path, 'database')
        os.makedirs(db_dir, exist_ok=True)

        # Check if database already has data
        try:
            existing_users = User.query.count()
            existing_books = Book.query.count()
        except Exception:
            # Tables might not exist yet
            existing_users = 0
            existing_books = 0

        if not force_reset and existing_users > 0:
            print("\n[INFO] Database already contains data:")
            print(f"  - Users: {existing_users}")
            print(f"  - Books: {existing_books}")
            print("Preserving existing data. No changes made.")
            print("To wipe and re-seed the database with fresh demonstration data, run:")
            print("  python seed.py --reset\n")
            return

        print("\n[+] Initializing database tables...")
        if force_reset:
            print("    Dropping existing tables (--reset specified)...")
            db.drop_all()
        db.create_all()

        print("[+] Seeding Administrator and Student accounts...")
        # 1. Administrator Account
        admin = User(
            full_name="Dr. Alan Turing (Librarian)",
            email="admin@library.edu",
            role=User.ROLE_ADMIN,
            department="Central University Library",
            phone="+91 98765 43210"
        )
        admin.set_password("Admin@123")
        db.session.add(admin)

        # 2. Student Accounts
        student1 = User(
            student_id="BT22CSE001",
            full_name="Rahul Sharma",
            email="rahul@student.edu",
            role=User.ROLE_STUDENT,
            department="Computer Science & Engineering",
            phone="+91 98765 00001"
        )
        student1.set_password("Student@123")

        student2 = User(
            student_id="BT22CSE015",
            full_name="Priya Patel",
            email="priya@student.edu",
            role=User.ROLE_STUDENT,
            department="AI & Data Science",
            phone="+91 98765 00002"
        )
        student2.set_password("Student@123")

        student3 = User(
            student_id="BT22CSE032",
            full_name="Amit Verma",
            email="amit@student.edu",
            role=User.ROLE_STUDENT,
            department="Information Technology",
            phone="+91 98765 00003"
        )
        student3.set_password("Student@123")

        db.session.add_all([student1, student2, student3])
        db.session.commit()

        print("[+] Seeding Book Categories...")
        # 3. Categories
        cat_cs = Category(
            name="Computer Science & Algorithms",
            description="Core computer science fundamentals, data structures, analysis of algorithms, and computational complexity.",
            icon_class="fa-laptop-code"
        )
        cat_ai = Category(
            name="Artificial Intelligence & ML",
            description="Machine learning models, deep neural networks, computer vision, natural language processing, and probabilistic reasoning.",
            icon_class="fa-brain"
        )
        cat_web = Category(
            name="Web Development & Cloud",
            description="Modern full-stack architectures, RESTful APIs, distributed cloud systems, microservices, and DevOps practices.",
            icon_class="fa-globe"
        )
        cat_ds = Category(
            name="Data Science & Big Data",
            description="Statistical data analysis, data warehousing, big data processing pipelines, and data-intensive distributed architectures.",
            icon_class="fa-database"
        )
        cat_sec = Category(
            name="Cyber Security & Cryptography",
            description="Network security, ethical hacking, cryptographic primitives, threat modeling, and secure software development.",
            icon_class="fa-shield-halved"
        )
        cat_se = Category(
            name="Software Engineering & System Design",
            description="Object-oriented design patterns, clean architecture, refactoring, agile methodologies, and scalable system design.",
            icon_class="fa-diagram-project"
        )

        categories = [cat_cs, cat_ai, cat_web, cat_ds, cat_sec, cat_se]
        db.session.add_all(categories)
        db.session.commit()

        print("[+] Seeding 24 Academic Computer Science Books...")
        # 4. Books
        books_data = [
            # CS & Algorithms
            {
                "title": "Introduction to Algorithms (CLRS)",
                "author": "Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein",
                "isbn": "978-0262033848",
                "publisher": "MIT Press",
                "publication_year": 2009,
                "category": cat_cs,
                "description": "Comprehensive reference covering dynamic programming, graph algorithms, divide-and-conquer, greedy heuristics, NP-completeness, and advanced data structures.",
                "total_copies": 5,
                "available_copies": 3
            },
            {
                "title": "Data Structures and Algorithm Analysis in C++",
                "author": "Mark Allen Weiss",
                "isbn": "978-0132847377",
                "publisher": "Pearson",
                "publication_year": 2013,
                "category": cat_cs,
                "description": "Explores binary search trees, hashing algorithms, heaps, AVL trees, sorting techniques, and asymptotic time and space complexity with C++ implementations.",
                "total_copies": 4,
                "available_copies": 4
            },
            {
                "title": "Operating System Concepts",
                "author": "Abraham Silberschatz, Peter B. Galvin, Greg Gagne",
                "isbn": "978-1119800361",
                "publisher": "Wiley",
                "publication_year": 2018,
                "category": cat_cs,
                "description": "Classic textbook examining process synchronization, threads, CPU scheduling algorithms, virtual memory paging, file systems, and operating system deadlocks.",
                "total_copies": 6,
                "available_copies": 4
            },
            {
                "title": "Computer Networks: A Top-Down Approach",
                "author": "James F. Kurose, Keith W. Ross",
                "isbn": "978-0136681557",
                "publisher": "Pearson",
                "publication_year": 2020,
                "category": cat_cs,
                "description": "In-depth treatment of computer networking protocols including HTTP, DNS, TCP congestion control, IP routing protocols, BGP, and wireless transport networks.",
                "total_copies": 5,
                "available_copies": 4
            },
            {
                "title": "Compilers: Principles, Techniques, and Tools",
                "author": "Alfred V. Aho, Monica S. Lam, Ravi Sethi, Jeffrey D. Ullman",
                "isbn": "978-0321486813",
                "publisher": "Pearson",
                "publication_year": 2006,
                "category": cat_cs,
                "description": "The Dragon Book. Essential theory and algorithms for lexical analysis, syntax parsing, syntax-directed translation, code optimization, and machine code generation.",
                "total_copies": 3,
                "available_copies": 3
            },

            # AI & Machine Learning
            {
                "title": "Artificial Intelligence: A Modern Approach",
                "author": "Stuart Russell, Peter Norvig",
                "isbn": "978-0134610993",
                "publisher": "Pearson",
                "publication_year": 2020,
                "category": cat_ai,
                "description": "The definitive AI guide covering intelligent agents, informed search, game theory, constraint satisfaction, probabilistic models, reinforcement learning, and robotics.",
                "total_copies": 5,
                "available_copies": 3
            },
            {
                "title": "Pattern Recognition and Machine Learning",
                "author": "Christopher M. Bishop",
                "isbn": "978-0387310732",
                "publisher": "Springer",
                "publication_year": 2006,
                "category": cat_ai,
                "description": "Rigorous Bayesian treatment of machine learning algorithms, Gaussian mixture models, linear regression, support vector machines, and expectation-maximization.",
                "total_copies": 4,
                "available_copies": 3
            },
            {
                "title": "Deep Learning",
                "author": "Ian Goodfellow, Yoshua Bengio, Aaron Courville",
                "isbn": "978-0262035613",
                "publisher": "MIT Press",
                "publication_year": 2016,
                "category": cat_ai,
                "description": "Covers deep feedforward networks, convolutional neural networks (CNNs), recurrent neural networks (RNNs), backpropagation, and generative adversarial networks (GANs).",
                "total_copies": 4,
                "available_copies": 2
            },
            {
                "title": "Hands-On Machine Learning with Scikit-Learn, Keras, and TensorFlow",
                "author": "Aurélien Géron",
                "isbn": "978-1098125974",
                "publisher": "O'Reilly Media",
                "publication_year": 2022,
                "category": cat_ai,
                "description": "Practical guide to constructing end-to-end machine learning pipelines, feature engineering, classification models, gradient boosting, and deep learning architectures.",
                "total_copies": 5,
                "available_copies": 4
            },
            {
                "title": "Machine Learning Yearning",
                "author": "Andrew Ng",
                "isbn": "978-0999053805",
                "publisher": "DeepLearning.AI",
                "publication_year": 2018,
                "category": cat_ai,
                "description": "Strategic machine learning guidelines for structuring ML projects, diagnosing bias versus variance, error analysis, and optimizing validation sets.",
                "total_copies": 4,
                "available_copies": 4
            },

            # Web Dev & Cloud
            {
                "title": "Full Stack Development with React and Node.js",
                "author": "David Choi",
                "isbn": "978-1801813839",
                "publisher": "Packt Publishing",
                "publication_year": 2022,
                "category": cat_web,
                "description": "Building modern responsive web applications with JavaScript, React hooks, Express backend services, REST APIs, JSON Web Tokens, and MongoDB integration.",
                "total_copies": 4,
                "available_copies": 3
            },
            {
                "title": "Python Crash Course",
                "author": "Eric Matthes",
                "isbn": "978-1718502703",
                "publisher": "No Starch Press",
                "publication_year": 2023,
                "category": cat_web,
                "description": "Hands-on project-based introduction to Python programming, web development with Django, data visualizations, and interactive web tools.",
                "total_copies": 5,
                "available_copies": 4
            },
            {
                "title": "Cloud Native DevOps with Kubernetes",
                "author": "John Arundel, Justin Domingus",
                "isbn": "978-1492040767",
                "publisher": "O'Reilly Media",
                "publication_year": 2019,
                "category": cat_web,
                "description": "Constructing robust containerized infrastructure using Docker, Kubernetes pods, ingress controllers, CI/CD automated deployment pipelines, and microservices.",
                "total_copies": 3,
                "available_copies": 3
            },
            {
                "title": "Fluent Python: Clear, Concise, and Effective Programming",
                "author": "Luciano Ramalho",
                "isbn": "978-1492056355",
                "publisher": "O'Reilly Media",
                "publication_year": 2022,
                "category": cat_web,
                "description": "Advanced idioms, decorators, type hints, asyncio concurrency, metaclasses, and data structures in idiomatic modern Python 3.",
                "total_copies": 4,
                "available_copies": 4
            },

            # Data Science & Big Data
            {
                "title": "Designing Data-Intensive Applications",
                "author": "Martin Kleppmann",
                "isbn": "978-1449373320",
                "publisher": "O'Reilly Media",
                "publication_year": 2017,
                "category": cat_ds,
                "description": "Architecting reliable, scalable, and maintainable systems: replication, partitioning, transactions, consensus protocols, batch pipelines, and stream processing.",
                "total_copies": 6,
                "available_copies": 4
            },
            {
                "title": "Database System Concepts",
                "author": "Abraham Silberschatz, Henry F. Korth, S. Sudarshan",
                "isbn": "978-0078022159",
                "publisher": "McGraw-Hill",
                "publication_year": 2019,
                "category": cat_ds,
                "description": "Relational data model, SQL queries, normalization up to BCNF, B-tree indexing, query optimization algorithms, transaction ACID properties, and concurrency control.",
                "total_copies": 5,
                "available_copies": 3
            },
            {
                "title": "Learning SQL: Generate, Manipulate, and Retrieve Data",
                "author": "Alan Beaulieu",
                "isbn": "978-1492057611",
                "publisher": "O'Reilly Media",
                "publication_year": 2020,
                "category": cat_ds,
                "description": "Essential relational queries, joins, grouping, subqueries, analytical window functions, transactions, and performance indexing.",
                "total_copies": 4,
                "available_copies": 4
            },
            {
                "title": "Python for Data Analysis",
                "author": "Wes McKinney",
                "isbn": "978-1098104030",
                "publisher": "O'Reilly Media",
                "publication_year": 2022,
                "category": cat_ds,
                "description": "Data manipulation, cleaning, aggregation, time series analysis, and statistical visualization using NumPy, Pandas, Matplotlib, and IPython.",
                "total_copies": 5,
                "available_copies": 4
            },

            # Cyber Security & Cryptography
            {
                "title": "Cryptography and Network Security",
                "author": "William Stallings",
                "isbn": "978-0134444284",
                "publisher": "Pearson",
                "publication_year": 2017,
                "category": cat_sec,
                "description": "Mathematical principles of symmetric encryption (AES, DES), asymmetric public-key cryptography (RSA, ECC), digital signatures, and TLS protocols.",
                "total_copies": 4,
                "available_copies": 3
            },
            {
                "title": "The Web Application Hacker's Handbook",
                "author": "Dafydd Stuttard, Marcus Pinto",
                "isbn": "978-1118026472",
                "publisher": "Wiley",
                "publication_year": 2011,
                "category": cat_sec,
                "description": "Discovering and exploiting security vulnerabilities including SQL injection, cross-site scripting (XSS), CSRF, session hijacking, and authorization flaws.",
                "total_copies": 3,
                "available_copies": 2
            },
            {
                "title": "Web Application Security: Exploitation and Countermeasures",
                "author": "Andrew Hoffman",
                "isbn": "978-1492053118",
                "publisher": "O'Reilly Media",
                "publication_year": 2020,
                "category": cat_sec,
                "description": "Modern web defense strategies, Content Security Policy, zero trust architecture, secure headers, subresource integrity, and vulnerability scanning.",
                "total_copies": 3,
                "available_copies": 3
            },

            # Software Engineering & System Design
            {
                "title": "Clean Code: A Handbook of Agile Software Craftsmanship",
                "author": "Robert C. Martin",
                "isbn": "978-0132350884",
                "publisher": "Prentice Hall",
                "publication_year": 2008,
                "category": cat_se,
                "description": "Best practices for writing meaningful names, concise functions, formatting, error handling, unit testing, refactoring, and SOLID design principles.",
                "total_copies": 5,
                "available_copies": 3
            },
            {
                "title": "The Pragmatic Programmer",
                "author": "David Thomas, Andrew Hunt",
                "isbn": "978-0135957059",
                "publisher": "Addison-Wesley",
                "publication_year": 2019,
                "category": cat_se,
                "description": "Software engineering philosophies covering DRY, orthogonality, automated testing, tracer bullets, domain languages, refactoring, and career mastery.",
                "total_copies": 4,
                "available_copies": 4
            },
            {
                "title": "Head First Design Patterns",
                "author": "Eric Freeman, Elisabeth Robson",
                "isbn": "978-1492078005",
                "publisher": "O'Reilly Media",
                "publication_year": 2020,
                "category": cat_se,
                "description": "Visually rich guide explaining Singleton, Observer, Factory, Strategy, Decorator, Adapter, and Composite object-oriented design patterns.",
                "total_copies": 4,
                "available_copies": 4
            }
        ]

        books = []
        for b_dict in books_data:
            book = Book(
                title=b_dict["title"],
                author=b_dict["author"],
                isbn=b_dict["isbn"],
                publisher=b_dict["publisher"],
                publication_year=b_dict["publication_year"],
                category=b_dict["category"],
                description=b_dict["description"],
                cover_image="default_cover.jpg",
                total_copies=b_dict["total_copies"],
                available_copies=b_dict["available_copies"]
            )
            books.append(book)
            db.session.add(book)

        db.session.commit()

        print("[+] Seeding Student Preferences...")
        # 5. User Preferences for Recommendations
        pref1 = UserPreference(user_id=student1.id, category_id=cat_ai.id)
        pref2 = UserPreference(user_id=student1.id, category_id=cat_cs.id)
        pref3 = UserPreference(user_id=student2.id, category_id=cat_ai.id)
        pref4 = UserPreference(user_id=student2.id, category_id=cat_ds.id)
        pref5 = UserPreference(user_id=student3.id, category_id=cat_web.id)
        pref6 = UserPreference(user_id=student3.id, category_id=cat_sec.id)

        db.session.add_all([pref1, pref2, pref3, pref4, pref5, pref6])
        db.session.commit()

        print("[+] Seeding Sample Borrow Records...")
        now = datetime.utcnow()

        clrs_book = Book.query.filter_by(title="Introduction to Algorithms (CLRS)").first()
        rec1 = BorrowRecord(
            user_id=student1.id,
            book_id=clrs_book.id,
            status=BorrowRecord.STATUS_ISSUED,
            request_date=now - timedelta(days=5),
            issue_date=now - timedelta(days=4),
            due_date=now + timedelta(days=10),
            fine_amount=0.0,
            notes="Issued for CS301 project work"
        )

        dl_book = Book.query.filter_by(title="Deep Learning").first()
        rec2 = BorrowRecord(
            user_id=student1.id,
            book_id=dl_book.id,
            status=BorrowRecord.STATUS_ISSUED,
            request_date=now - timedelta(days=25),
            issue_date=now - timedelta(days=22),
            due_date=now - timedelta(days=8),
            fine_amount=40.0,
            notes="Overdue reminder email sent"
        )

        ddia_book = Book.query.filter_by(title="Designing Data-Intensive Applications").first()
        rec3 = BorrowRecord(
            user_id=student2.id,
            book_id=ddia_book.id,
            status=BorrowRecord.STATUS_ISSUED,
            request_date=now - timedelta(days=3),
            issue_date=now - timedelta(days=2),
            due_date=now + timedelta(days=12),
            fine_amount=0.0
        )

        aima_book = Book.query.filter_by(title="Artificial Intelligence: A Modern Approach").first()
        rec4 = BorrowRecord(
            user_id=student2.id,
            book_id=aima_book.id,
            status=BorrowRecord.STATUS_RETURNED,
            request_date=now - timedelta(days=40),
            issue_date=now - timedelta(days=38),
            due_date=now - timedelta(days=24),
            return_date=now - timedelta(days=26),
            fine_amount=0.0,
            notes="Returned in excellent condition"
        )

        wahh_book = Book.query.filter_by(title="The Web Application Hacker's Handbook").first()
        rec5 = BorrowRecord(
            user_id=student3.id,
            book_id=wahh_book.id,
            status=BorrowRecord.STATUS_PENDING,
            request_date=now - timedelta(hours=6),
            notes="Requesting for Security Lab assignment"
        )

        db.session.add_all([rec1, rec2, rec3, rec4, rec5])
        db.session.commit()

        print("[+] Seeding Sample Reviews & Ratings...")
        # 6. Reviews
        rev1 = Review(
            user_id=student2.id,
            book_id=aima_book.id,
            rating=5,
            review_text="Absolute masterpiece for understanding AI heuristics and search algorithms. Clear explanations and modern real-world examples."
        )
        rev2 = Review(
            user_id=student1.id,
            book_id=clrs_book.id,
            rating=5,
            review_text="The ultimate competitive programming and academic algorithms guide. Dynamic programming chapter is peerless."
        )
        rev3 = Review(
            user_id=student2.id,
            book_id=ddia_book.id,
            rating=5,
            review_text="Best systems book ever written! Explains distributed data, replication, and consensus in a deeply intuitive manner."
        )
        clean_code_book = Book.query.filter_by(title="Clean Code: A Handbook of Agile Software Craftsmanship").first()
        rev4 = Review(
            user_id=student3.id,
            book_id=clean_code_book.id,
            rating=4,
            review_text="Very helpful guidelines for naming conventions and keeping functions short. Must read for software engineering lab."
        )

        db.session.add_all([rev1, rev2, rev3, rev4])
        db.session.commit()

        print("\n========================================================")
        print(" [SUCCESS] Database seeding completed successfully!")
        print("========================================================")
        print(f" Total Users:         {User.query.count()} (1 Admin, 3 Students)")
        print(f" Total Categories:    {Category.query.count()}")
        print(f" Total Books:         {Book.query.count()} titles")
        print(f" Total Borrow Records:{BorrowRecord.query.count()} transactions")
        print(f" Total Reviews:       {Review.query.count()} reviews")
        print("--------------------------------------------------------")
        print(" Administrator Login: admin@library.edu / Admin@123")
        print(" Student Login:       rahul@student.edu / Student@123")
        print("========================================================\n")

if __name__ == '__main__':
    force = '--reset' in sys.argv or '-f' in sys.argv or '--force' in sys.argv
    seed_database(force_reset=force)
