from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError
from models import User

class LoginForm(FlaskForm):
    """Form for both Student and Administrator authentication."""
    email = StringField('Email Address', validators=[
        DataRequired(message='Please provide your email address.'),
        Email(message='Please enter a valid academic email address.', check_deliverability=False)
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Please enter your password.')
    ])
    remember_me = BooleanField('Keep me signed in')
    submit = SubmitField('Sign In')

class RegistrationForm(FlaskForm):
    """Self-registration form for University Students."""
    student_id = StringField('Student Roll / Card Number', validators=[
        DataRequired(message='Student ID is required.'),
        Length(min=4, max=30, message='Student ID must be between 4 and 30 characters.')
    ])
    full_name = StringField('Full Name', validators=[
        DataRequired(message='Full name is required.'),
        Length(min=2, max=100, message='Name must be between 2 and 100 characters.')
    ])
    email = StringField('Email Address', validators=[
        DataRequired(message='Email is required.'),
        Email(message='Enter a valid email address.', check_deliverability=False)
    ])
    department = SelectField('Academic Department', choices=[
        ('Computer Science & Engineering', 'Computer Science & Engineering'),
        ('AI & Data Science', 'AI & Data Science'),
        ('Information Technology', 'Information Technology'),
        ('Electronics & Communication', 'Electronics & Communication'),
        ('Mechanical Engineering', 'Mechanical Engineering'),
        ('Electrical Engineering', 'Electrical Engineering')
    ], validators=[DataRequired()])
    phone = StringField('Contact Phone Number', validators=[
        Length(max=20)
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Password is required.'),
        Length(min=6, message='Password must be at least 6 characters long.')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(message='Please confirm your password.'),
        EqualTo('password', message='Passwords must match.')
    ])
    submit = SubmitField('Create Student Account')

    def validate_email(self, field):
        """Ensures that the student email is unique."""
        existing_user = User.query.filter_by(email=field.data.strip().lower()).first()
        if existing_user:
            raise ValidationError('An account with this email address is already registered.')

    def validate_student_id(self, field):
        """Ensures that the student ID number is unique."""
        existing_id = User.query.filter_by(student_id=field.data.strip().upper()).first()
        if existing_id:
            raise ValidationError('A student with this Roll/Card Number already exists.')
