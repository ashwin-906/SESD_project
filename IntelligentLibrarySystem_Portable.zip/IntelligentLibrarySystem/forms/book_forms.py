from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, IntegerField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, NumberRange, Optional, ValidationError
from models import Book, Category

class BookForm(FlaskForm):
    """Form used by administrators to add and edit library book records."""
    title = StringField('Book Title', validators=[
        DataRequired(message='Book title is required.'),
        Length(max=200, message='Title cannot exceed 200 characters.')
    ])
    author = StringField('Author(s)', validators=[
        DataRequired(message='Author name is required.'),
        Length(max=150, message='Author name cannot exceed 150 characters.')
    ])
    isbn = StringField('ISBN Number', validators=[
        DataRequired(message='ISBN is required.'),
        Length(min=9, max=20, message='ISBN should be between 9 and 20 characters.')
    ])
    publisher = StringField('Publisher', validators=[
        Optional(),
        Length(max=150)
    ])
    publication_year = IntegerField('Publication Year', validators=[
        Optional(),
        NumberRange(min=1800, max=2100, message='Enter a valid four-digit year.')
    ])
    category_id = SelectField('Category', coerce=int, validators=[
        DataRequired(message='Please choose a category.')
    ])
    description = TextAreaField('Book Description & Overview', validators=[
        DataRequired(message='Please provide a descriptive overview for recommendation matching.')
    ])
    total_copies = IntegerField('Total Inventory Copies', default=1, validators=[
        DataRequired(message='Total copies count is required.'),
        NumberRange(min=1, message='Total copies must be at least 1.')
    ])
    available_copies = IntegerField('Available Copies', default=1, validators=[
        NumberRange(min=0, message='Available copies cannot be negative.')
    ])
    submit = SubmitField('Save Book Record')

    def __init__(self, original_isbn=None, *args, **kwargs):
        super(BookForm, self).__init__(*args, **kwargs)
        self.original_isbn = original_isbn
        # Dynamically populate categories choices
        self.category_id.choices = [
            (c.id, c.name) for c in Category.query.order_by(Category.name.asc()).all()
        ]

    def validate_isbn(self, field):
        """Ensures ISBN is unique unless unchanged on edit."""
        isbn_val = field.data.strip()
        if self.original_isbn and isbn_val == self.original_isbn:
            return
        existing_book = Book.query.filter_by(isbn=isbn_val).first()
        if existing_book:
            raise ValidationError('A book with this ISBN is already registered in the catalogue.')

    def validate_available_copies(self, field):
        """Ensures available copies does not exceed total copies."""
        if field.data is not None and self.total_copies.data is not None:
            if field.data > self.total_copies.data:
                raise ValidationError('Available copies cannot exceed total copies.')

class CategoryForm(FlaskForm):
    """Form to create or edit book categories."""
    name = StringField('Category Name', validators=[
        DataRequired(message='Category name is required.'),
        Length(max=80)
    ])
    description = TextAreaField('Description', validators=[
        Optional()
    ])
    icon_class = SelectField('Category Icon', choices=[
        ('fa-laptop-code', 'Laptop / Code (Computer Science)'),
        ('fa-brain', 'Brain / Neural (AI & ML)'),
        ('fa-globe', 'Globe / Web (Web & Cloud)'),
        ('fa-database', 'Database / Storage (Data Science)'),
        ('fa-shield-halved', 'Shield (Cyber Security)'),
        ('fa-diagram-project', 'Diagram / Project (Software Engineering)'),
        ('fa-book', 'General Book'),
        ('fa-robot', 'Robot / Automation'),
        ('fa-network-wired', 'Network / Infrastructure'),
        ('fa-calculator', 'Math / Algorithms')
    ], default='fa-book')
    submit = SubmitField('Save Category')

    def __init__(self, original_name=None, *args, **kwargs):
        super(CategoryForm, self).__init__(*args, **kwargs)
        self.original_name = original_name

    def validate_name(self, field):
        name_val = field.data.strip()
        if self.original_name and name_val.lower() == self.original_name.lower():
            return
        if Category.query.filter(Category.name.ilike(name_val)).first():
            raise ValidationError('A category with this name already exists.')
