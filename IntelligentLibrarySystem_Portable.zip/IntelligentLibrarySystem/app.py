import os
from datetime import datetime
from flask import Flask, render_template, redirect, url_for
from flask_login import LoginManager, current_user
from flask_wtf.csrf import CSRFProtect

from config import config_by_name
from models import db, User, Category

# Global Flask extension instances
login_manager = LoginManager()
csrf = CSRFProtect()

def create_app(config_name=None):
    """
    Application factory pattern.
    Configures database, security extensions, blueprints, and error handlers.
    """
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')

    app = Flask(__name__)
    app.config.from_object(config_by_name.get(config_name, config_by_name['default']))

    # Ensure instance/database directory exists
    db_dir = os.path.join(app.root_path, 'database')
    os.makedirs(db_dir, exist_ok=True)

    # Initialize extensions with app context
    db.init_app(app)
    csrf.init_app(app)

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'warning'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        """Loads user by ID for Flask-Login session."""
        return db.session.get(User, int(user_id))

    # Register blueprints
    from routes.auth import auth_bp
    from routes.admin import admin_bp
    from routes.student import student_bp
    from routes.api import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(api_bp)

    # Root route redirect
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            if current_user.is_admin:
                return redirect(url_for('admin.dashboard'))
            return redirect(url_for('student.dashboard'))
        return redirect(url_for('auth.login'))

    # Context processors: injects global variables into all Jinja templates
    @app.context_processor
    def inject_globals():
        return {
            'now': datetime.utcnow(),
            'current_year': datetime.utcnow().year,
            'app_name': 'SmartLib AI',
            'all_categories': Category.query.order_by(Category.name.asc()).all() if db.engine else []
        }

    # Error handlers
    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/403.html'), 403

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    return app

if __name__ == '__main__':
    app = create_app('development')
    with app.app_context():
        db.create_all()
    print("Starting Intelligent Library Management System...")
    app.run(host='127.0.0.1', port=5000, debug=True)
