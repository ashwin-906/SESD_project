from datetime import datetime
from models import db

class BorrowRecord(db.Model):
    """
    BorrowRecord tracks the full borrowing transaction lifecycle:
    PENDING (student requested) -> APPROVED / REJECTED (admin reviewed) ->
    ISSUED (book physically collected, copies decremented) -> RETURNED (copies restored, fine computed).
    """
    __tablename__ = 'borrow_records'

    STATUS_PENDING = 'PENDING'
    STATUS_APPROVED = 'APPROVED'
    STATUS_REJECTED = 'REJECTED'
    STATUS_ISSUED = 'ISSUED'
    STATUS_RETURNED = 'RETURNED'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'), nullable=False, index=True)
    status = db.Column(db.String(20), default=STATUS_PENDING, nullable=False, index=True)
    request_date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    issue_date = db.Column(db.DateTime, nullable=True)
    due_date = db.Column(db.DateTime, nullable=True)
    return_date = db.Column(db.DateTime, nullable=True)
    fine_amount = db.Column(db.Float, default=0.0, nullable=False)
    notes = db.Column(db.Text, nullable=True)

    @property
    def is_overdue(self) -> bool:
        """Determines if the book has passed its due date without being returned."""
        if self.status == self.STATUS_ISSUED and self.due_date:
            return datetime.utcnow() > self.due_date
        return False

    @property
    def overdue_days(self) -> int:
        """Returns the number of overdue days as an integer."""
        if not self.due_date:
            return 0
        end_date = self.return_date if self.return_date else datetime.utcnow()
        if end_date > self.due_date:
            delta = end_date - self.due_date
            return max(0, delta.days)
        return 0

    def compute_fine(self, daily_rate: float = 5.0) -> float:
        """Calculates total fine based on days overdue and daily rate."""
        days = self.overdue_days
        return round(days * daily_rate, 2)

    @property
    def status_badge_class(self) -> str:
        """CSS class helper for UI badge rendering."""
        mapping = {
            self.STATUS_PENDING: 'badge-warning',
            self.STATUS_APPROVED: 'badge-info',
            self.STATUS_REJECTED: 'badge-danger',
            self.STATUS_ISSUED: 'badge-primary',
            self.STATUS_RETURNED: 'badge-success'
        }
        if self.is_overdue:
            return 'badge-danger'
        return mapping.get(self.status, 'badge-secondary')

    def __repr__(self):
        return f"<BorrowRecord #{self.id} User:{self.user_id} Book:{self.book_id} Status:{self.status}>"
