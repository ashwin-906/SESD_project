from datetime import datetime
from models import db

class Category(db.Model):
    """
    Category model classifying books into academic and technical genres
    (e.g., Computer Science, Artificial Intelligence, Web Development).
    """
    __tablename__ = 'categories'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    icon_class = db.Column(db.String(50), default='fa-book', nullable=False) # Font Awesome icon class
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    books = db.relationship('Book', backref='category', lazy='dynamic')
    preferences = db.relationship('UserPreference', backref='category', lazy='dynamic', cascade='all, delete-orphan')

    @property
    def book_count(self) -> int:
        """Returns the total number of book titles in this category."""
        return self.books.count()

    def __repr__(self):
        return f"<Category {self.name}>"
