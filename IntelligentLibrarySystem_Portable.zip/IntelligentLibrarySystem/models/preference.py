from sqlalchemy import UniqueConstraint
from models import db

class UserPreference(db.Model):
    """
    Stores a student's chosen favourite categories.
    Used by the recommendation engine for personalized filtering and cold-start suggestions.
    """
    __tablename__ = 'user_preferences'
    __table_args__ = (
        UniqueConstraint('user_id', 'category_id', name='unique_user_category_preference'),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False, index=True)

    def __repr__(self):
        return f"<UserPreference User:{self.user_id} Cat:{self.category_id}>"
