from datetime import datetime
from sqlalchemy import CheckConstraint
from models import db

class Book(db.Model):
    """
    Book model representing a distinct book in the library catalogue.
    Tracks metadata, category, and real-time inventory copy counts.
    """
    __tablename__ = 'books'
    __table_args__ = (
        CheckConstraint('available_copies >= 0', name='check_available_copies_non_negative'),
        CheckConstraint('total_copies >= 1', name='check_total_copies_positive'),
        CheckConstraint('available_copies <= total_copies', name='check_available_not_exceed_total')
    )

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    author = db.Column(db.String(150), nullable=False, index=True)
    isbn = db.Column(db.String(20), unique=True, nullable=False, index=True)
    publisher = db.Column(db.String(150), nullable=True)
    publication_year = db.Column(db.Integer, nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False, index=True)
    description = db.Column(db.Text, nullable=False)
    cover_image = db.Column(db.String(255), default='default_cover.jpg', nullable=False)
    total_copies = db.Column(db.Integer, nullable=False, default=1)
    available_copies = db.Column(db.Integer, nullable=False, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    borrow_records = db.relationship('BorrowRecord', backref='book', lazy='dynamic', cascade='all, delete-orphan')
    reviews = db.relationship('Review', backref='book', lazy='dynamic', cascade='all, delete-orphan')

    @property
    def is_available(self) -> bool:
        """Indicates whether at least one copy is currently available to borrow."""
        return self.available_copies > 0

    @property
    def issued_copies(self) -> int:
        """Returns the number of copies currently out on loan."""
        return max(0, self.total_copies - self.available_copies)

    @property
    def average_rating(self) -> float:
        """Calculates the average user rating (1-5) across all reviews."""
        all_reviews = self.reviews.all()
        if not all_reviews:
            return 0.0
        return round(sum(r.rating for r in all_reviews) / len(all_reviews), 1)

    @property
    def total_reviews_count(self) -> int:
        """Returns the count of user reviews submitted for this book."""
        return self.reviews.count()

    @property
    def status_label(self) -> str:
        """Returns human-friendly stock status text for badge display."""
        if self.available_copies == 0:
            return "Out of Stock"
        elif self.available_copies <= 2:
            return "Low Stock"
        return "In Stock"

    def get_features_text(self) -> str:
        """
        Combines title, author, category, publisher, and description into a
        unified feature text used by the TF-IDF vectorizer.
        """
        cat_name = self.category.name if self.category else ""
        return f"{self.title} {self.author} {cat_name} {self.publisher or ''} {self.description}".lower()

    def __repr__(self):
        return f"<Book '{self.title}' by {self.author}>"
