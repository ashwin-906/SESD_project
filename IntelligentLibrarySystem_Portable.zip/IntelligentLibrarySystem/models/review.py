from datetime import datetime
from sqlalchemy import UniqueConstraint, CheckConstraint
from models import db

class Review(db.Model):
    """
    Stores student ratings (1 to 5 stars) and optional written reviews for books.
    Provides sentiment and preference signals to the recommendation engine.
    """
    __tablename__ = 'reviews'
    __table_args__ = (
        UniqueConstraint('user_id', 'book_id', name='unique_user_book_review'),
        CheckConstraint('rating >= 1 AND rating <= 5', name='check_rating_range'),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'), nullable=False, index=True)
    rating = db.Column(db.Integer, nullable=False)
    review_text = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return f"<Review Book:{self.book_id} Rating:{self.rating} by User:{self.user_id}>"
