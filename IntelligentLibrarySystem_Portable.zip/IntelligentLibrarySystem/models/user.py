from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from models import db

class User(UserMixin, db.Model):
    """
    User model representing both Administrators (Librarians) and Students.
    Inherits from Flask-Login's UserMixin for session management.
    """
    __tablename__ = 'users'

    ROLE_ADMIN = 'admin'
    ROLE_STUDENT = 'student'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.String(50), unique=True, nullable=True, index=True) # e.g. "BT22CSE045", null for admin
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default=ROLE_STUDENT)
    department = db.Column(db.String(100), nullable=True) # e.g. "Computer Science & Engineering"
    phone = db.Column(db.String(20), nullable=True)
    is_active_account = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    borrow_records = db.relationship('BorrowRecord', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    preferences = db.relationship('UserPreference', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    reviews = db.relationship('Review', backref='user', lazy='dynamic', cascade='all, delete-orphan')

    def set_password(self, password: str):
        """Hashes and stores the user's password securely."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        """Verifies an incoming plain-text password against the stored hash."""
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self) -> bool:
        """Returns True if the user has an administrator role."""
        return self.role == self.ROLE_ADMIN

    @property
    def is_student(self) -> bool:
        """Returns True if the user has a student role."""
        return self.role == self.ROLE_STUDENT

    @property
    def active_loans_count(self) -> int:
        """Counts how many books are currently issued to this student."""
        from models.borrow import BorrowRecord
        return self.borrow_records.filter(BorrowRecord.status == BorrowRecord.STATUS_ISSUED).count()

    @property
    def pending_requests_count(self) -> int:
        """Counts how many book borrow requests are currently awaiting admin review."""
        from models.borrow import BorrowRecord
        return self.borrow_records.filter(BorrowRecord.status == BorrowRecord.STATUS_PENDING).count()

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"
