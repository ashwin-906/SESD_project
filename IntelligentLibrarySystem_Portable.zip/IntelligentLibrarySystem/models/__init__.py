from flask_sqlalchemy import SQLAlchemy

# Single SQLAlchemy database instance used across models
db = SQLAlchemy()

from models.user import User
from models.category import Category
from models.book import Book
from models.borrow import BorrowRecord
from models.preference import UserPreference
from models.review import Review

__all__ = ['db', 'User', 'Category', 'Book', 'BorrowRecord', 'UserPreference', 'Review']
