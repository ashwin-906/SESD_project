@echo off
title Intelligent Library Management System - SmartLib AI
color 0A

echo ==============================================================================
echo       INTELLIGENT LIBRARY MANAGEMENT SYSTEM WITH BOOK RECOMMENDATION
echo ==============================================================================
echo.

:: 1. Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to your system PATH.
    echo Please install Python 3.10+ from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

:: 2. Check if venv exists, if not create it
if not exist "venv\Scripts\activate.bat" (
    echo [*] Creating clean Python virtual environment (venv)...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo [OK] Virtual environment created successfully.
    echo.

    echo [*] Installing required Python dependencies from requirements.txt...
    call venv\Scripts\activate.bat
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to install dependencies.
        pause
        exit /b 1
    )
    echo [OK] Dependencies installed successfully.
    echo.
) else (
    call venv\Scripts\activate.bat
)

:: 3. Seed database if library.db doesn't exist
if not exist "database\library.db" (
    echo [*] First-time setup detected. Initializing database and seeding demo data...
    python seed.py
    echo [OK] Database seeded successfully.
    echo.
)

:: 4. Start Flask server and open browser
echo ==============================================================================
echo  Starting SmartLib AI Application Server...
echo  Local URL: http://127.0.0.1:5000
echo  Press Ctrl+C in this terminal window to stop the server.
echo ==============================================================================
echo.

start http://127.0.0.1:5000
python app.py

pause
