from urllib.parse import urlparse
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from forms.auth_forms import LoginForm, RegistrationForm
from models import db, User

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

def is_safe_redirect_url(target):
    """Protects against open-redirect vulnerabilities by verifying path is relative."""
    if not target:
        return False
    ref_url = urlparse(request.host_url)
    test_url = urlparse(target)
    return test_url.scheme in ('', 'http', 'https') and ref_url.netloc == test_url.netloc or not test_url.netloc

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handles both Administrator and Student authentication."""
    if current_user.is_authenticated:
        if current_user.is_admin:
            return redirect(url_for('admin.dashboard'))
        return redirect(url_for('student.dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        password = form.password.data
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            if not user.is_active_account:
                flash('Your account has been deactivated. Please contact the administrator.', 'danger')
                return render_template('auth/login.html', form=form)

            login_user(user, remember=form.remember_me.data)
            flash(f'Welcome back, {user.full_name}!', 'success')

            next_page = request.args.get('next')
            if next_page and is_safe_redirect_url(next_page):
                return redirect(next_page)

            if user.is_admin:
                return redirect(url_for('admin.dashboard'))
            return redirect(url_for('student.dashboard'))
        else:
            flash('Invalid email address or password. Please verify your credentials.', 'danger')

    return render_template('auth/login.html', form=form)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Allows new students to register for library access."""
    if current_user.is_authenticated:
        return redirect(url_for('student.dashboard'))

    form = RegistrationForm()
    if form.validate_on_submit():
        new_student = User(
            student_id=form.student_id.data.strip().upper(),
            full_name=form.full_name.data.strip(),
            email=form.email.data.strip().lower(),
            department=form.department.data,
            phone=form.phone.data.strip() if form.phone.data else None,
            role=User.ROLE_STUDENT
        )
        new_student.set_password(form.password.data)

        db.session.add(new_student)
        db.session.commit()

        flash('Your student account was created successfully! You can now log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html', form=form)

@auth_bp.route('/logout')
@login_required
def logout():
    """Terminates the user session securely."""
    logout_user()
    flash('You have been signed out successfully.', 'info')
    return redirect(url_for('auth.login'))
