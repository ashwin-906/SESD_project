from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, current_app
from flask_login import current_user, login_required
from services.auth_guards import student_required
from models import db, Book, Category, BorrowRecord, UserPreference, Review

student_bp = Blueprint('student', __name__, url_prefix='/student')

from services.recommendation_service import recommendation_engine

@student_bp.route('/dashboard')
@student_required
def dashboard():
    """
    Student Personalized Hub:
    Displays quick stats, active loans, upcoming due dates,
    favourite categories, and AI book recommendations.
    """
    user_id = current_user.id
    
    # Active borrowings
    active_loans = BorrowRecord.query.filter_by(
        user_id=user_id,
        status=BorrowRecord.STATUS_ISSUED
    ).order_by(BorrowRecord.due_date.asc()).all()

    # Pending requests
    pending_requests = BorrowRecord.query.filter_by(
        user_id=user_id,
        status=BorrowRecord.STATUS_PENDING
    ).order_by(BorrowRecord.request_date.desc()).all()

    # User's chosen favourite categories
    preferences = current_user.preferences.all()
    user_cat_ids = [p.category_id for p in preferences]
    favourite_categories = Category.query.filter(Category.id.in_(user_cat_ids)).all() if user_cat_ids else []

    # Intelligent recommendations powered by TF-IDF & Cosine Similarity
    recommendations = recommendation_engine.get_personalized_recommendations(user_id=user_id, top_n=5)

    return render_template(
        'student/dashboard.html',
        active_loans=active_loans,
        pending_requests=pending_requests,
        favourite_categories=favourite_categories,
        recommendations=recommendations
    )

@student_bp.route('/catalogue')
def catalogue():
    """
    Public and Student Book Catalogue:
    Features multi-field search (title, author, ISBN), category filtering,
    stock availability filtering, and sorting.
    """
    query = request.args.get('q', '').strip()
    category_id = request.args.get('category_id', type=int)
    sort_by = request.args.get('sort', 'newest')
    available_only = request.args.get('available_only') == '1'

    books_query = Book.query

    # Search filter
    if query:
        search_filter = f"%{query}%"
        books_query = books_query.filter(
            db.or_(
                Book.title.ilike(search_filter),
                Book.author.ilike(search_filter),
                Book.isbn.ilike(search_filter),
                Book.publisher.ilike(search_filter),
                Book.description.ilike(search_filter)
            )
        )

    # Category filter
    if category_id:
        books_query = books_query.filter(Book.category_id == category_id)

    # Availability filter
    if available_only:
        books_query = books_query.filter(Book.available_copies > 0)

    # Sorting
    if sort_by == 'title':
        books_query = books_query.order_by(Book.title.asc())
    elif sort_by == 'author':
        books_query = books_query.order_by(Book.author.asc())
    elif sort_by == 'year':
        books_query = books_query.order_by(Book.publication_year.desc())
    else:  # newest
        books_query = books_query.order_by(Book.created_at.desc())

    books_list = books_query.all()
    categories = Category.query.order_by(Category.name.asc()).all()

    return render_template(
        'student/catalogue.html',
        books=books_list,
        categories=categories,
        current_query=query,
        current_category=category_id,
        current_sort=sort_by,
        available_only=available_only,
        total_results=len(books_list)
    )

@student_bp.route('/books/<int:book_id>')
def book_detail(book_id):
    """
    Detailed information page for an individual book:
    Displays complete metadata, real-time availability, borrowing eligibility,
    user ratings & reviews, and related titles in the same category.
    """
    book = db.session.get(Book, book_id)
    if not book:
        abort(404)

    user_active_borrow = None
    existing_user_review = None

    if current_user.is_authenticated and current_user.is_student:
        user_active_borrow = BorrowRecord.query.filter(
            BorrowRecord.user_id == current_user.id,
            BorrowRecord.book_id == book.id,
            BorrowRecord.status.in_([BorrowRecord.STATUS_PENDING, BorrowRecord.STATUS_ISSUED, BorrowRecord.STATUS_APPROVED])
        ).first()

        existing_user_review = Review.query.filter_by(
            user_id=current_user.id,
            book_id=book.id
        ).first()

    # Similar thematic books computed via TF-IDF Cosine Similarity
    similar_books_data = recommendation_engine.get_similar_books(book_id=book.id, top_n=4)
    similar_books = [item['book'] for item in similar_books_data]

    reviews = book.reviews.order_by(Review.created_at.desc()).all()

    return render_template(
        'student/book_detail.html',
        book=book,
        reviews=reviews,
        user_active_borrow=user_active_borrow,
        existing_user_review=existing_user_review,
        similar_books=similar_books
    )

# ---------------------------------------------------------
# Borrow Request & Reviews Handlers
# ---------------------------------------------------------

@student_bp.route('/request-borrow/<int:book_id>', methods=['POST'])
@student_required
def request_borrow(book_id):
    """Places a new borrow request for a book."""
    book = db.session.get(Book, book_id)
    if not book:
        abort(404)

    # 1. Check availability
    if book.available_copies <= 0:
        flash(f"Sorry, '{book.title}' is currently out of stock.", 'danger')
        return redirect(url_for('student.book_detail', book_id=book.id))

    # 2. Check for duplicate active borrow or request
    active_record = BorrowRecord.query.filter(
        BorrowRecord.user_id == current_user.id,
        BorrowRecord.book_id == book.id,
        BorrowRecord.status.in_([BorrowRecord.STATUS_PENDING, BorrowRecord.STATUS_APPROVED, BorrowRecord.STATUS_ISSUED])
    ).first()

    if active_record:
        flash(f"You already have an active request or loan for '{book.title}'.", 'warning')
        return redirect(url_for('student.book_detail', book_id=book.id))

    # 3. Check student active loan limit
    max_loans = current_app.config.get('MAX_ACTIVE_LOANS_PER_STUDENT', 3)
    if current_user.active_loans_count >= max_loans:
        flash(f"Borrow limit reached: You cannot hold more than {max_loans} active loans simultaneously.", 'warning')
        return redirect(url_for('student.my_loans'))

    # Create new pending request
    new_request = BorrowRecord(
        user_id=current_user.id,
        book_id=book.id,
        status=BorrowRecord.STATUS_PENDING
    )
    db.session.add(new_request)
    db.session.commit()

    flash(f"Borrow request for '{book.title}' submitted! The librarian will review and approve your request.", 'success')
    return redirect(url_for('student.my_loans'))

@student_bp.route('/submit-review/<int:book_id>', methods=['POST'])
@student_required
def submit_review(book_id):
    """Submits or updates a student rating and written review."""
    book = db.session.get(Book, book_id)
    if not book:
        abort(404)

    rating_raw = request.form.get('rating')
    review_text = request.form.get('review_text', '').strip()

    try:
        rating = int(rating_raw)
        if rating < 1 or rating > 5:
            raise ValueError
    except (TypeError, ValueError):
        flash('Invalid rating score. Please choose between 1 and 5 stars.', 'danger')
        return redirect(url_for('student.book_detail', book_id=book.id))

    existing_review = Review.query.filter_by(
        user_id=current_user.id,
        book_id=book.id
    ).first()

    if existing_review:
        existing_review.rating = rating
        existing_review.review_text = review_text if review_text else None
        db.session.commit()
        flash('Your review and rating were updated successfully!', 'success')
    else:
        new_review = Review(
            user_id=current_user.id,
            book_id=book.id,
            rating=rating,
            review_text=review_text if review_text else None
        )
        db.session.add(new_review)
        db.session.commit()
        flash('Thank you! Your review and rating were published.', 'success')

    return redirect(url_for('student.book_detail', book_id=book.id))

@student_bp.route('/my-loans')
@student_required
def my_loans():
    """Displays student's loan ledger: current loans, pending requests, and return history."""
    records = BorrowRecord.query.filter_by(user_id=current_user.id).order_by(BorrowRecord.request_date.desc()).all()
    active_loans = [r for r in records if r.status == BorrowRecord.STATUS_ISSUED]
    pending_requests = [r for r in records if r.status in (BorrowRecord.STATUS_PENDING, BorrowRecord.STATUS_APPROVED)]
    past_loans = [r for r in records if r.status in (BorrowRecord.STATUS_RETURNED, BorrowRecord.STATUS_REJECTED)]

    return render_template(
        'student/my_loans.html',
        records=records,
        active_loans=active_loans,
        pending_requests=pending_requests,
        past_loans=past_loans
    )

@student_bp.route('/my-loans/<int:record_id>/cancel', methods=['POST'])
@student_required
def cancel_request(record_id):
    """Allows student to cancel a pending borrow request."""
    from services.library_service import LibraryService
    success, msg = LibraryService.cancel_student_request(record_id, current_user.id)
    flash(msg, 'info' if success else 'danger')
    return redirect(url_for('student.my_loans'))

@student_bp.route('/preferences', methods=['GET', 'POST'])
@student_required
def preferences():
    """Allows students to pick and update their favourite academic categories."""
    if request.method == 'POST':
        selected_category_ids = request.form.getlist('category_ids', type=int)

        # Clear existing preferences
        UserPreference.query.filter_by(user_id=current_user.id).delete()

        # Add newly selected preferences
        for cat_id in selected_category_ids:
            if Category.query.get(cat_id):
                db.session.add(UserPreference(user_id=current_user.id, category_id=cat_id))

        db.session.commit()
        flash('Your reading interests have been updated! AI recommendations refreshed.', 'success')
        return redirect(url_for('student.dashboard'))

    categories = Category.query.order_by(Category.name.asc()).all()
    user_pref_ids = [p.category_id for p in current_user.preferences.all()]
    return render_template('student/preferences.html', categories=categories, user_pref_ids=user_pref_ids)
