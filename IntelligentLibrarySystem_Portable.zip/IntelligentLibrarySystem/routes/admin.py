from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, current_app
from services.auth_guards import admin_required
from services.library_service import LibraryService
from models import db, Book, Category, User, BorrowRecord, Review
from forms.book_forms import BookForm, CategoryForm

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    """Main Administrator KPI Overview."""
    total_books = Book.query.count()
    total_students = User.query.filter_by(role=User.ROLE_STUDENT).count()
    
    all_books = Book.query.all()
    total_copies = sum(b.total_copies for b in all_books)
    available_copies = sum(b.available_copies for b in all_books)
    issued_copies = total_copies - available_copies
    
    pending_requests = BorrowRecord.query.filter_by(status=BorrowRecord.STATUS_PENDING).count()
    active_loans_count = BorrowRecord.query.filter_by(status=BorrowRecord.STATUS_ISSUED).count()
    
    now = datetime.utcnow()
    overdue_loans = BorrowRecord.query.filter(
        BorrowRecord.status == BorrowRecord.STATUS_ISSUED,
        BorrowRecord.due_date < now
    ).count()

    recent_records = BorrowRecord.query.order_by(BorrowRecord.request_date.desc()).limit(6).all()
    recent_reviews = Review.query.order_by(Review.created_at.desc()).limit(4).all()

    return render_template(
        'admin/dashboard.html',
        total_books=total_books,
        total_students=total_students,
        total_copies=total_copies,
        available_copies=available_copies,
        issued_copies=issued_copies,
        pending_requests=pending_requests,
        active_loans_count=active_loans_count,
        overdue_loans=overdue_loans,
        recent_records=recent_records,
        recent_reviews=recent_reviews
    )

# ---------------------------------------------------------
# Book Inventory Management
# ---------------------------------------------------------

@admin_bp.route('/books')
@admin_required
def books():
    """Displays book catalogue table with search, category filtering, and inventory status."""
    query = request.args.get('q', '').strip()
    category_id = request.args.get('category_id', type=int)

    books_query = Book.query
    if query:
        search_filter = f"%{query}%"
        books_query = books_query.filter(
            db.or_(
                Book.title.ilike(search_filter),
                Book.author.ilike(search_filter),
                Book.isbn.ilike(search_filter)
            )
        )
    if category_id:
        books_query = books_query.filter(Book.category_id == category_id)

    books_list = books_query.order_by(Book.created_at.desc()).all()
    categories = Category.query.order_by(Category.name.asc()).all()

    return render_template(
        'admin/books.html',
        books=books_list,
        categories=categories,
        current_query=query,
        current_category=category_id
    )

@admin_bp.route('/books/new', methods=['GET', 'POST'])
@admin_required
def new_book():
    """Allows administrators to register a new book in the library catalogue."""
    form = BookForm()
    if form.validate_on_submit():
        book = Book(
            title=form.title.data.strip(),
            author=form.author.data.strip(),
            isbn=form.isbn.data.strip(),
            publisher=form.publisher.data.strip() if form.publisher.data else None,
            publication_year=form.publication_year.data,
            category_id=form.category_id.data,
            description=form.description.data.strip(),
            total_copies=form.total_copies.data,
            available_copies=form.available_copies.data
        )
        db.session.add(book)
        db.session.commit()
        flash(f"Book '{book.title}' was successfully added to the catalogue.", 'success')
        return redirect(url_for('admin.books'))

    return render_template('admin/book_form.html', form=form, title='Add New Book', is_edit=False)

@admin_bp.route('/books/<int:book_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_book(book_id):
    """Allows administrators to modify metadata or inventory levels of an existing book."""
    book = db.session.get(Book, book_id)
    if not book:
        abort(404)

    form = BookForm(original_isbn=book.isbn, obj=book)
    if form.validate_on_submit():
        book.title = form.title.data.strip()
        book.author = form.author.data.strip()
        book.isbn = form.isbn.data.strip()
        book.publisher = form.publisher.data.strip() if form.publisher.data else None
        book.publication_year = form.publication_year.data
        book.category_id = form.category_id.data
        book.description = form.description.data.strip()
        book.total_copies = form.total_copies.data
        book.available_copies = form.available_copies.data
        book.updated_at = datetime.utcnow()

        db.session.commit()
        flash(f"Book '{book.title}' details updated successfully.", 'success')
        return redirect(url_for('admin.books'))

    return render_template('admin/book_form.html', form=form, title=f"Edit '{book.title}'", is_edit=True, book=book)

@admin_bp.route('/books/<int:book_id>/delete', methods=['POST'])
@admin_required
def delete_book(book_id):
    """Safely deletes a book record if not currently issued."""
    book = db.session.get(Book, book_id)
    if not book:
        abort(404)

    active_loans = BorrowRecord.query.filter_by(
        book_id=book.id,
        status=BorrowRecord.STATUS_ISSUED
    ).count()

    if active_loans > 0:
        flash(f"Cannot delete '{book.title}'. There are currently {active_loans} copy(ies) on loan to students.", 'danger')
        return redirect(url_for('admin.books'))

    title = book.title
    db.session.delete(book)
    db.session.commit()
    flash(f"Book '{title}' was permanently deleted from the catalogue.", 'info')
    return redirect(url_for('admin.books'))

# ---------------------------------------------------------
# Category Management
# ---------------------------------------------------------

@admin_bp.route('/categories', methods=['GET', 'POST'])
@admin_required
def categories():
    """Lists categories and handles creation of new categories."""
    form = CategoryForm()
    if form.validate_on_submit():
        category = Category(
            name=form.name.data.strip(),
            description=form.description.data.strip() if form.description.data else None,
            icon_class=form.icon_class.data
        )
        db.session.add(category)
        db.session.commit()
        flash(f"Category '{category.name}' created successfully.", 'success')
        return redirect(url_for('admin.categories'))

    all_categories = Category.query.order_by(Category.name.asc()).all()
    return render_template('admin/categories.html', categories=all_categories, form=form)

@admin_bp.route('/categories/<int:category_id>/delete', methods=['POST'])
@admin_required
def delete_category(category_id):
    """Deletes category only if no books are assigned to it."""
    category = db.session.get(Category, category_id)
    if not category:
        abort(404)

    if category.books.count() > 0:
        flash(f"Cannot delete '{category.name}'. It contains {category.books.count()} book(s). Reassign them first.", 'danger')
        return redirect(url_for('admin.categories'))

    name = category.name
    db.session.delete(category)
    db.session.commit()
    flash(f"Category '{name}' deleted successfully.", 'info')
    return redirect(url_for('admin.categories'))

# ---------------------------------------------------------
# Borrow Requests Management (Approval / Rejection)
# ---------------------------------------------------------

@admin_bp.route('/requests')
@admin_required
def borrow_requests():
    """Queue of student borrow requests awaiting librarian action."""
    pending_list = BorrowRecord.query.filter_by(
        status=BorrowRecord.STATUS_PENDING
    ).order_by(BorrowRecord.request_date.asc()).all()

    return render_template('admin/borrow_requests.html', requests=pending_list)

@admin_bp.route('/requests/<int:record_id>/approve', methods=['POST'])
@admin_required
def approve_request(record_id):
    """Approves a student's pending borrow request."""
    success, msg = LibraryService.approve_request(record_id)
    flash(msg, 'success' if success else 'danger')
    return redirect(url_for('admin.borrow_requests'))

@admin_bp.route('/requests/<int:record_id>/reject', methods=['POST'])
@admin_required
def reject_request(record_id):
    """Rejects a student's pending borrow request."""
    reason = request.form.get('reason')
    success, msg = LibraryService.reject_request(record_id, reason=reason)
    flash(msg, 'info' if success else 'danger')
    return redirect(url_for('admin.borrow_requests'))

# ---------------------------------------------------------
# Issue & Return Operations
# ---------------------------------------------------------

@admin_bp.route('/loans')
@admin_required
def active_loans():
    """Operations dashboard for issuing books, recording returns, and inspecting overdue items."""
    tab = request.args.get('tab', 'active')

    # Approved requests ready to be issued
    ready_to_issue = BorrowRecord.query.filter(
        BorrowRecord.status.in_([BorrowRecord.STATUS_APPROVED, BorrowRecord.STATUS_PENDING])
    ).order_by(BorrowRecord.request_date.asc()).all()

    # Currently issued books
    active_loans_list = BorrowRecord.query.filter_by(
        status=BorrowRecord.STATUS_ISSUED
    ).order_by(BorrowRecord.due_date.asc()).all()

    # Overdue subset
    now = datetime.utcnow()
    overdue_list = [r for r in active_loans_list if r.is_overdue]

    # Completed returns
    returned_list = BorrowRecord.query.filter_by(
        status=BorrowRecord.STATUS_RETURNED
    ).order_by(BorrowRecord.return_date.desc()).limit(20).all()

    return render_template(
        'admin/active_loans.html',
        current_tab=tab,
        ready_to_issue=ready_to_issue,
        active_loans=active_loans_list,
        overdue_loans=overdue_list,
        returned_loans=returned_list,
        now=now
    )

@admin_bp.route('/loans/<int:record_id>/issue', methods=['POST'])
@admin_required
def issue_book(record_id):
    """Issues a book to a student, decrementing available stock."""
    loan_days = request.form.get('loan_days', type=int) or current_app.config.get('DEFAULT_LOAN_DAYS', 14)
    success, msg = LibraryService.issue_book(record_id, loan_days=loan_days)
    flash(msg, 'success' if success else 'danger')
    return redirect(url_for('admin.active_loans', tab='active'))

@admin_bp.route('/loans/<int:record_id>/return', methods=['POST'])
@admin_required
def return_book(record_id):
    """Records the return of an issued book, restoring available stock."""
    daily_fine_rate = current_app.config.get('DAILY_FINE_RATE', 5.0)
    success, msg = LibraryService.return_book(record_id, daily_fine_rate=daily_fine_rate)
    flash(msg, 'success' if success else 'danger')
    return redirect(url_for('admin.active_loans', tab='active'))

# ---------------------------------------------------------
# Student Directory
# ---------------------------------------------------------

@admin_bp.route('/students')
@admin_required
def students():
    """Displays directory of all registered university students."""
    query = request.args.get('q', '').strip()
    students_query = User.query.filter_by(role=User.ROLE_STUDENT)

    if query:
        search_filter = f"%{query}%"
        students_query = students_query.filter(
            db.or_(
                User.full_name.ilike(search_filter),
                User.student_id.ilike(search_filter),
                User.email.ilike(search_filter),
                User.department.ilike(search_filter)
            )
        )

    students_list = students_query.order_by(User.created_at.desc()).all()
    return render_template('admin/students.html', students=students_list, current_query=query)

@admin_bp.route('/students/<int:student_id>')
@admin_required
def student_detail(student_id):
    """Detailed audit view of a student's profile, active loans, and history."""
    student = db.session.get(User, student_id)
    if not student or not student.is_student:
        abort(404)

    records = BorrowRecord.query.filter_by(user_id=student.id).order_by(BorrowRecord.request_date.desc()).all()
    preferences = student.preferences.all()

    return render_template('admin/student_detail.html', student=student, records=records, preferences=preferences)
