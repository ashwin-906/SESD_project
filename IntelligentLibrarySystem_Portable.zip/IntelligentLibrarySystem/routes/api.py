from flask import Blueprint, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func
from models import db, Book, Category, BorrowRecord, Review
from services.recommendation_service import recommendation_engine

api_bp = Blueprint('api', __name__, url_prefix='/api')

@api_bp.route('/analytics/dashboard-charts')
@login_required
def dashboard_charts():
    """
    Returns aggregated JSON data for Chart.js visualizations
    on the Administrator Dashboard.
    """
    # 1. Most Borrowed Books (Top 5)
    most_borrowed_query = (
        db.session.query(
            Book.title,
            func.count(BorrowRecord.id).label('borrow_count')
        )
        .join(BorrowRecord, Book.id == BorrowRecord.book_id)
        .group_by(Book.id)
        .order_by(func.count(BorrowRecord.id).desc())
        .limit(5)
        .all()
    )

    if not most_borrowed_query:
        # Fallback if few borrow records
        books = Book.query.limit(5).all()
        most_borrowed_labels = [b.title[:22] + "..." if len(b.title) > 25 else b.title for b in books]
        most_borrowed_counts = [b.total_copies - b.available_copies for b in books]
    else:
        most_borrowed_labels = [
            r[0][:22] + "..." if len(r[0]) > 25 else r[0] for r in most_borrowed_query
        ]
        most_borrowed_counts = [r[1] for r in most_borrowed_query]

    # 2. Category Distribution
    categories = Category.query.all()
    category_labels = [c.name for c in categories]
    category_counts = [c.books.count() for c in categories]

    # 3. Loan Status Distribution
    from datetime import datetime
    now = datetime.utcnow()
    pending_cnt = BorrowRecord.query.filter_by(status=BorrowRecord.STATUS_PENDING).count()
    active_cnt = BorrowRecord.query.filter(
        BorrowRecord.status == BorrowRecord.STATUS_ISSUED,
        BorrowRecord.due_date >= now
    ).count()
    overdue_cnt = BorrowRecord.query.filter(
        BorrowRecord.status == BorrowRecord.STATUS_ISSUED,
        BorrowRecord.due_date < now
    ).count()
    returned_cnt = BorrowRecord.query.filter_by(status=BorrowRecord.STATUS_RETURNED).count()

    return jsonify({
        'most_borrowed': {
            'labels': most_borrowed_labels,
            'data': most_borrowed_counts
        },
        'category_distribution': {
            'labels': category_labels,
            'data': category_counts
        },
        'status_distribution': {
            'labels': ['Active Loans', 'Overdue Loans', 'Pending Requests', 'Returned Books'],
            'data': [active_cnt, overdue_cnt, pending_cnt, returned_cnt]
        }
    })

@api_bp.route('/recommendations')
@login_required
def get_recommendations():
    """Returns JSON recommendations for dynamic AJAX updating."""
    if not current_user.is_student:
        return jsonify({'error': 'Student login required'}), 403

    recs = recommendation_engine.get_personalized_recommendations(user_id=current_user.id, top_n=5)
    data = []
    for r in recs:
        book = r['book']
        data.append({
            'id': book.id,
            'title': book.title,
            'author': book.author,
            'category': book.category.name,
            'available_copies': book.available_copies,
            'rating': book.average_rating,
            'score': r['score'],
            'reason': r['reason']
        })
    return jsonify({'recommendations': data})
