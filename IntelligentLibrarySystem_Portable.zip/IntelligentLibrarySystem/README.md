# Intelligent Library Management System with Book Recommendation

> **Academic Project Submission**  
> **Degree:** Bachelor of Technology (B.Tech) in Computer Science & Engineering  
> **Domain:** Web Development, Database Systems & Applied Machine Learning  
> **Portability:** Fully self-contained. Runs on any Windows, macOS, or Linux machine with Python 3.10+ installed.

---

## 1. Project Overview

The **Intelligent Library Management System with Book Recommendation** is a full-stack web application designed for university academic libraries. It automates traditional circulation and inventory management while delivering a machine-learning-driven book recommendation engine.

Traditional library systems act as simple databases. This project bridges operations and applied intelligence by combining:
1. **Full Circulation Lifecycle:** Book inventory CRUD, role-based access control, borrow requests approval queue, physical issue/return tracking, and automatic overdue fine assessment (₹5.00/day).
2. **Applied Machine Learning:** An intelligent content-based recommendation service using **Scikit-Learn TF-IDF Vectorization** and **Cosine Similarity** on book metadata (titles, authors, categories, descriptions) to generate personalized suggestions with transparent explanations.
3. **Interactive Analytics:** Real-time data visualization powered by **Chart.js**.

---

## 2. Key Features by Role

### 👨‍💼 Administrator / Librarian Portal
- **KPI Operations Dashboard:** Real-time summary cards for total books, inventory copy count, registered students, active loans, pending approvals, and overdue loans.
- **Chart.js Visual Analytics:**
  - *Most Borrowed Books* (Bar chart).
  - *Category Breakdown* (Doughnut chart).
  - *Circulation Status Breakdown* (Doughnut chart).
- **Book Inventory Management:** Add, edit, and delete books with constraints preventing negative stock and duplicate ISBNs.
- **Academic Category Management:** Categorize books into disciplines (AI, CS, Web Development, Data Science, Cyber Security, Software Engineering).
- **Borrow Requests Queue:** Review student requests, verify current shelf stock, and approve or reject.
- **Issue & Return Operations:** Physical issuing (atomic copy decrements) and return logging (automatic fine calculation).
- **Student Directory & Audit:** View registered students, current loans, and complete historical loan ledgers.

### 🎓 Student Portal
- **Student Registration & Login:** Academic registration with roll number, department, email, and password hashing.
- **Searchable Book Catalogue:** Live multi-field search (Title, Author, ISBN, Publisher) with category filter pills, stock availability toggle, and sorting options.
- **Book Details & Thematic Recommendations:** Detailed book specifications, verified student reviews, stock status badges, and similar books in the same discipline.
- **One-Click Borrow Requests:** Submit borrow requests with built-in loan limits (maximum 3 active loans) and duplicate prevention.
- **Personalized "My Loans" Ledger:** Monitor active borrowings, due dates, countdowns, overdue warnings, and cancel pending requests.
- **Ratings & Reviews:** Submit 1 to 5 star ratings and reviews with instant average rating calculation.
- **Personalized AI Recommendations:** Top-5 content-based recommendations on the dashboard, complete with human-readable explanations (*"Why recommended"*).

---

## 3. Technology Stack

| Component | Technology | Version | Purpose |
|---|---|---|---|
| **Backend Framework** | Python / Flask | 3.0.3 | Web routing, blueprints, application factory |
| **Database & ORM** | SQLite 3 / Flask-SQLAlchemy | 3.1.1 | Relational database, transactions, constraints |
| **Authentication** | Flask-Login | 0.6.3 | Session management, remember me cookies |
| **Password Hashing** | Werkzeug | 3.0.3 | Secure password hashing (`scrypt`/`pbkdf2`) |
| **Forms & CSRF** | Flask-WTF / WTForms | 1.2.1 | Form validation and CSRF defense |
| **Email Validation** | email-validator | 2.3.0 | Academic email syntax validation |
| **Machine Learning** | Scikit-Learn | 1.5.0 | TF-IDF Vectorizer & Cosine Similarity |
| **Numerical Computing**| NumPy | 1.26.4 | Vector math and matrix similarity computations |
| **Data Structures** | Pandas | 2.2.2 | Structured book metadata processing |
| **Data Visualization** | Chart.js | 4.4 | Interactive dashboard charts |
| **Frontend Styling** | HTML5, CSS3, Bootstrap | 5.3.3 | Responsive modern design with CSS variables |
| **Icons** | Font Awesome | 6.5.1 | Iconography |
| **Automated Testing** | Pytest | 8.2.2 | Automated unit & integration testing |
| **Environment Config** | python-dotenv | 1.0.1 | Portable `.env` file management |

---

## 4. Machine Learning Recommendation Architecture

The recommendation engine is implemented in [`services/recommendation_service.py`](services/recommendation_service.py).

### 4.1 Feature Extraction: TF-IDF Vectorization
For every book $b$ in the catalogue, a rich textual bag is constructed:
$$\text{Corpus}(b) = \text{Title}_b \oplus \text{Title}_b \oplus \text{Author}_b \oplus \text{Category}_b \oplus \text{Category}_b \oplus \text{Description}_b$$
*(Note: Title and Category terms are doubled to give them higher term frequency priority in the vector space).*

The **Term Frequency - Inverse Document Frequency (TF-IDF)** assigns weights to terms based on their relative significance:
1. **Term Frequency ($TF$):**
   $$TF(t, d) = \frac{f_{t, d}}{\sum_{t' \in d} f_{t', d}}$$
   *With sublinear logarithmic TF scaling:* $w_{t, d} = 1 + \log(TF(t, d))$ for $TF > 0$.
2. **Inverse Document Frequency ($IDF$):**
   $$IDF(t, D) = \log\left(\frac{1 + |D|}{1 + |\{d \in D : t \in d\}|}\right) + 1$$
3. **Composite TF-IDF Weight:**
   $$\text{TF-IDF}(t, d, D) = TF(t, d) \times IDF(t, D)$$

### 4.2 Dynamic Student Profile Representation
A student interest vector $\vec{v}_{student}$ is dynamically synthesized from three weighted interaction signals:
$$\vec{v}_{student} = 2.0 \sum_{b \in \text{Borrowed}} \vec{v}_b + 1.5 \sum_{b \in \text{Liked}} \vec{v}_b + 1.0 \sum_{c \in \text{FavCats}} \vec{v}_c$$
Where:
- $\vec{v}_b$ is the normalized TF-IDF vector of a previously borrowed book (weight $2.0$).
- Books rated $\ge 4$ stars receive an additional positive weight ($1.5$).
- Explicitly chosen category preferences receive a base interest weight ($1.0$).

The composite vector is normalized using Euclidean $L_2$ norm:
$$\hat{v}_{student} = \frac{\vec{v}_{student}}{\|\vec{v}_{student}\|_2}$$

### 4.3 Ranking via Cosine Similarity
The similarity score between the student profile vector $\hat{v}_{student}$ and each candidate book $\vec{v}_{candidate}$ is calculated by:
$$\text{Cosine Similarity}(\hat{v}_{student}, \vec{v}_{candidate}) = \frac{\hat{v}_{student} \cdot \vec{v}_{candidate}}{\|\hat{v}_{student}\|_2 \|\vec{v}_{candidate}\|_2}$$

The top 5 books with the highest similarity are recommended, automatically excluding books the student has already borrowed and books currently out of stock.

### 4.4 Cold-Start Handling
- **New Student with Selected Interests:** Suggests top-rated books matching their selected categories.
- **New Student with No History:** Suggests trending library titles based on average ratings and overall borrowing popularity.

---

## 5. Transferring & Running on Another Laptop (Portability Guide)

This project uses **project-relative paths** and standard environment variables. You can transfer the entire project folder to any other Windows laptop and run it without path errors.

### Step 1: Copy the Project Folder
Copy the `IntelligentLibrarySystem/` folder to the target laptop (via USB, zip file, or Git).
> **Important:** Do NOT copy the `venv/` folder if it exists. Virtual environments are machine-specific. You will create a fresh virtual environment in Step 3.

### Step 2: Open Terminal in Project Folder
Open **PowerShell** or **Command Prompt** and navigate into the project directory:
```powershell
cd C:\path\to\IntelligentLibrarySystem
```

### Step 3: Create a Fresh Virtual Environment
```powershell
python -m venv venv
```

### Step 4: Activate the Virtual Environment
- **On PowerShell:**
  ```powershell
  .\venv\Scripts\Activate.ps1
  ```
  *(If PowerShell shows a `running scripts is disabled` message, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` once in your PowerShell window, then activate again).*
- **On Command Prompt (CMD):**
  ```cmd
  venv\Scripts\activate.bat
  ```

### Step 5: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 6: Configure Environment (Optional)
The project includes a pre-configured `.env` file that works out of the box. You can inspect or modify it, or create one from `.env.example`:
```powershell
copy .env.example .env
```

### Step 7: Initialize Database & Sample Data
- If you transferred the folder **with** `database/library.db`, all your existing data is already preserved.
- If this is a fresh setup or you want to re-seed initial demonstration data (24 books, categories, admin, students, loans, reviews), run:
  ```powershell
  python seed.py
  ```
  *(To force wipe and re-seed from scratch at any time, run: `python seed.py --reset`)*.

### Step 8: Start the Web Application
```powershell
python app.py
```
Open your browser and navigate to:
👉 **`http://127.0.0.1:5000`**

---

## 6. Demonstration Accounts for Viva & Evaluation

Pre-configured accounts are ready to demonstrate:

| Role | Email | Password | Features to Showcase |
|---|---|---|---|
| **Administrator / Librarian** | `admin@library.edu` | `Admin@123` | Dashboard with Chart.js analytics, approve/reject student requests, issue & return books, view overdue books with automatic fine calculation, manage book inventory |
| **Student (Warm Profile)** | `rahul@student.edu` | `Student@123` | Personalized AI recommendations on dashboard based on borrowed AI/ML books, "My Loans" ledger, overdue fine warnings, book rating & review submission |
| **Student (Cold Start)** | `amit@student.edu` | `Student@123` | Category-based onboarding recommendations tailored to chosen interests (Web Dev & Cyber Security) |

*(Tip: The login page includes **"Fill Admin"** and **"Fill Student"** quick-fill buttons for effortless demonstration during evaluation).*

---

## 7. Running the Automated Test Suite

To verify system integrity on the target machine, run:
```powershell
python -m pytest -v
```

All 24 automated unit tests will execute:
```text
tests/test_analytics.py::test_student_review_submission_and_average_rating PASSED
tests/test_analytics.py::test_analytics_dashboard_charts_api PASSED
tests/test_auth.py::test_login_page_renders PASSED
tests/test_auth.py::test_student_registration_success PASSED
tests/test_auth.py::test_student_registration_duplicate_email_fails PASSED
tests/test_auth.py::test_admin_login_success PASSED
tests/test_auth.py::test_student_login_success PASSED
tests/test_auth.py::test_login_invalid_password PASSED
tests/test_auth.py::test_role_isolation_student_denied_admin_dashboard PASSED
tests/test_auth.py::test_logout PASSED
tests/test_books.py::test_catalogue_renders PASSED
tests/test_books.py::test_catalogue_search_and_filter PASSED
tests/test_books.py::test_admin_add_book_success PASSED
tests/test_books.py::test_admin_prevent_duplicate_isbn PASSED
tests/test_books.py::test_admin_delete_book_blocked_if_issued PASSED
tests/test_borrowing.py::test_student_request_borrow_success PASSED
tests/test_borrowing.py::test_prevent_duplicate_active_borrow_request PASSED
tests/test_borrowing.py::test_prevent_borrow_out_of_stock_book PASSED
tests/test_borrowing.py::test_admin_approve_and_issue_workflow PASSED
tests/test_borrowing.py::test_admin_return_and_fine_calculation PASSED
tests/test_borrowing.py::test_student_cancel_pending_request PASSED
tests/test_recommendation.py::test_similar_books_pairwise_similarity PASSED
tests/test_recommendation.py::test_personalized_recommendations_from_borrow_history PASSED
tests/test_recommendation.py::test_cold_start_category_preferences PASSED

============================= 24 passed in 20.18s =============================
```

---

## 8. Viva Voce & Academic Defense Questions

### Q1: Why did you choose Content-Based Filtering instead of Collaborative Filtering?
> **Answer:** In university academic libraries, new editions and books are constantly added, and students graduate every year. Collaborative filtering suffers heavily from the **cold-start problem** because it requires a large matrix of user interactions. Content-Based Filtering with TF-IDF allows us to immediately recommend any newly catalogued book based purely on its title, author, category, and descriptive concepts, without needing prior ratings from other students.

### Q2: What is the purpose of TF-IDF and how does it work?
> **Answer:** TF-IDF stands for Term Frequency - Inverse Document Frequency.
> - **Term Frequency ($TF$):** Counts how often a keyword appears in a book's description.
> - **Inverse Document Frequency ($IDF$):** Penalizes generic words (e.g., *"book"*, *"study"*, *"chapter"*) that appear everywhere and amplifies domain-specific technical terms (e.g., *"backpropagation"*, *"neural"*, *"consensus"*).
> Multiplying $TF \times IDF$ produces a high weight only for terms that are frequent in that specific book but rare across the general library catalogue.

### Q3: How do you measure similarity between student interests and books?
> **Answer:** We convert both the student profile (weighted combination of borrowed books and favorite categories) and every library book into multi-dimensional TF-IDF vectors. We then calculate the **Cosine Similarity** between them:
> $$\cos(\theta) = \frac{\vec{u} \cdot \vec{v}}{\|\vec{u}\| \|\vec{v}\|}$$
> The cosine value ranges between $0$ (completely unrelated) and $1$ (exact match). We rank candidate books by this score and display the top 5.

### Q4: How is data integrity guaranteed during concurrent book borrowing?
> **Answer:** The database enforces a SQL check constraint `available_copies >= 0`. Additionally, the issuing process in `LibraryService.issue_book()` is performed inside an atomic transaction that validates `available_copies > 0` before decrementing and committing. If a concurrent operation violates stock limits, SQLAlchemy rolls back the transaction.

### Q5: How is security implemented in the system?
> **Answer:**
> 1. Passwords are never stored in plain text; they are hashed using Werkzeug's secure hashing (`scrypt`/`pbkdf2`).
> 2. Role-based authorization decorators (`@admin_required` and `@student_required`) guard every sensitive route on the backend.
> 3. CSRF protection is enforced on all state-changing forms using Flask-WTF tokens.
> 4. SQL injection is mitigated through parameterized queries via SQLAlchemy ORM.
